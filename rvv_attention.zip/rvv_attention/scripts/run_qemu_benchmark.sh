#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$ROOT_DIR/build-riscv}"
BIN="${BENCH_BIN:-$BUILD_DIR/attention_rvv_bench}"
QEMU="${QEMU_RISCV64:-$HOME/riscv-gnu-toolchain/qemu/build-rvv/qemu-riscv64}"
CXX="${RISCV_CXX:-$HOME/opt/riscv/bin/riscv64-unknown-linux-gnu-g++}"
VLEN="${RVV_VLEN:-128}"
WARMUP="${WARMUP:-10}"
REPEAT="${REPEAT:-100}"
TOL="${TOL:-1e-4}"
OUT="${OUT:-$BUILD_DIR/qemu_attention_rvv_baseline_vs_v2.csv}"

if [[ ! -x "$BIN" ]]; then
  echo "Missing benchmark binary: $BIN"
  echo "Run scripts/build_qemu_benchmark.sh first."
  exit 1
fi

if [[ ! -x "$QEMU" ]] && ! command -v "$QEMU" >/dev/null 2>&1; then
  echo "QEMU not found: $QEMU"
  exit 1
fi

if [[ ! -x "$CXX" ]] && ! command -v "$CXX" >/dev/null 2>&1; then
  echo "RISC-V compiler not found: $CXX"
  exit 1
fi

SYSROOT="$("$CXX" -print-sysroot)"
if [[ -z "$SYSROOT" ]]; then
  echo "Could not determine RISC-V sysroot from $CXX"
  exit 1
fi

mkdir -p "$(dirname "$OUT")"

echo "mode,kv,K,N,repeat,original_rvv_median_us,v2_median_us,speedup_v2_vs_original,max_abs_error,checksum" > "$OUT"

KV_LIST=(8 16 32 64 128 256 512 1024 1500)

run_one() {
  local mode="$1"
  local kv="$2"

  "$QEMU" \
    -L "$SYSROOT" \
    -cpu "rv64,v=true,vlen=$VLEN" \
    "$BIN" \
    --mode "$mode" \
    --kv "$kv" \
    --warmup "$WARMUP" \
    --repeat "$REPEAT" \
    --tol "$TOL" \
    --csv \
    >> "$OUT"
}

echo "QEMU=$QEMU"
echo "CXX=$CXX"
echo "SYSROOT=$SYSROOT"
echo "VLEN=$VLEN WARMUP=$WARMUP REPEAT=$REPEAT TOL=$TOL"
echo

for kv in "${KV_LIST[@]}"; do run_one qk "$kv"; done
for kv in "${KV_LIST[@]}"; do run_one pv "$kv"; done

echo
echo "Saved: $OUT"
column -s, -t "$OUT" 2>/dev/null || cat "$OUT"

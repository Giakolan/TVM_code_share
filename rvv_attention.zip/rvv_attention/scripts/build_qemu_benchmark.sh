#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TVM_ROOT="${TVM_ROOT:-$HOME/tvm-byoc-kiwipedia-RVV/tvm}"
CXX="${RISCV_CXX:-$HOME/opt/riscv/bin/riscv64-unknown-linux-gnu-g++}"
BUILD_DIR="${BUILD_DIR:-$ROOT_DIR/build-riscv}"

if [[ ! -x "$CXX" ]] && ! command -v "$CXX" >/dev/null 2>&1; then
  echo "RISC-V compiler not found: $CXX"
  echo "Expected default: $HOME/opt/riscv/bin/riscv64-unknown-linux-gnu-g++"
  exit 1
fi

mkdir -p "$BUILD_DIR"

COMMON=(
  -O3 -DNDEBUG -std=c++17
  -march=rv64gcv -mabi=lp64d
)

echo "[1/4] Original RVV MatMul baseline"
"$CXX" "${COMMON[@]}" \
  -c "$ROOT_DIR/kernels/libattention_matmul_rvv_baseline.cpp" \
  -o "$BUILD_DIR/libattention_matmul_rvv_baseline.o"

echo "[2/4] Current RVV v2"
"$CXX" "${COMMON[@]}" \
  -I"$TVM_ROOT/3rdparty/dlpack/include" \
  -c "$ROOT_DIR/kernels/libattention_matmul_rvv.cpp" \
  -o "$BUILD_DIR/libattention_matmul_rvv_v2.o"

echo "[3/4] Benchmark driver"
"$CXX" "${COMMON[@]}" \
  -c "$ROOT_DIR/benchmark/benchmark_attention_rvv.cpp" \
  -o "$BUILD_DIR/benchmark_attention_rvv.o"

echo "[4/4] Link"
"$CXX" "${COMMON[@]}" \
  "$BUILD_DIR/libattention_matmul_rvv_baseline.o" \
  "$BUILD_DIR/libattention_matmul_rvv_v2.o" \
  "$BUILD_DIR/benchmark_attention_rvv.o" \
  -o "$BUILD_DIR/attention_rvv_bench"

echo
file "$BUILD_DIR/attention_rvv_bench"
echo "Built: $BUILD_DIR/attention_rvv_bench"
echo "Comparison: original RVV MatMul baseline vs current RVV v2"

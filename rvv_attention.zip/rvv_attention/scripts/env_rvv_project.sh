#!/usr/bin/env bash
# Source this file:
#   source scripts/env_rvv_project.sh

export PROJECT_HOME="${PROJECT_HOME:-$HOME/tvm-byoc-kiwipedia-RVV}"
export TVM_HOME="${TVM_HOME:-$PROJECT_HOME/tvm}"
export WHISPER_HOME="${WHISPER_HOME:-$PROJECT_HOME/whisper-tiny}"
export ONNX_HOME="${ONNX_HOME:-$WHISPER_HOME/onnx}"

export PYTHONPATH="$TVM_HOME/python:${PYTHONPATH:-}"
export LD_LIBRARY_PATH="$TVM_HOME/build:${LD_LIBRARY_PATH:-}"

# Host-side BYOC libraries. Do not load RISC-V .so files into x86 Python.
export KIWIPEDIA_MATMUL_SO="$TVM_HOME/src/runtime/contrib/kiwipedia/libmatmul.so"
export KIWIPEDIA_KV_CACHE_SO="$TVM_HOME/src/runtime/contrib/kiwipedia/libkv_cache_kernel.so"

# Current attention implementation is treated as v2/latest.
export KIWIPEDIA_TRACE_ATTENTION="${KIWIPEDIA_TRACE_ATTENTION:-1}"
export KIWIPEDIA_ATTENTION_KERNEL_LABEL="${KIWIPEDIA_ATTENTION_KERNEL_LABEL:-attention_rvv_v2}"

# Known working local RISC-V toolchain/QEMU defaults.
export RISCV_TOOLCHAIN_BIN="${RISCV_TOOLCHAIN_BIN:-$HOME/opt/riscv/bin}"
export PATH="$RISCV_TOOLCHAIN_BIN:$PATH"
export RISCV_CXX="${RISCV_CXX:-$RISCV_TOOLCHAIN_BIN/riscv64-unknown-linux-gnu-g++}"
export QEMU_RISCV64="${QEMU_RISCV64:-$HOME/riscv-gnu-toolchain/qemu/build-rvv/qemu-riscv64}"
export RVV_VLEN="${RVV_VLEN:-128}"

printf '%s\n' \
  "PROJECT_HOME=$PROJECT_HOME" \
  "TVM_HOME=$TVM_HOME" \
  "RISCV_CXX=$RISCV_CXX" \
  "QEMU_RISCV64=$QEMU_RISCV64" \
  "RVV_VLEN=$RVV_VLEN" \
  "KIWIPEDIA_ATTENTION_KERNEL_LABEL=$KIWIPEDIA_ATTENTION_KERNEL_LABEL"

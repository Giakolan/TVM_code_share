RVV Attention comparison patch
==============================

Purpose
-------
Compare:
  original RVV MatMul baseline
vs
  current kernels/libattention_matmul_rvv.cpp (RVV v2/latest)

The old scalar reference is no longer part of the benchmark.

Files
-----
kernels/libattention_matmul_rvv_baseline.cpp
benchmark/benchmark_attention_rvv.cpp
scripts/build_qemu_benchmark.sh
scripts/run_qemu_benchmark.sh
scripts/env_rvv_project.sh
install.sh

Result CSV
----------
build-riscv/qemu_attention_rvv_baseline_vs_v2.csv

speedup_v2_vs_original =
  original_rvv_median_us / v2_median_us

> 1.0 : v2 faster
= 1.0 : same
< 1.0 : v2 slower

Install
-------
From the extracted patch directory:

  ./install.sh

Then:

  cd ~/tvm-byoc-kiwipedia-RVV/rvv_attention
  source scripts/env_rvv_project.sh
  rm -rf build-riscv
  ./scripts/build_qemu_benchmark.sh
  ./scripts/run_qemu_benchmark.sh

The installer backs up replaced benchmark/scripts automatically and never
overwrites kernels/libattention_matmul_rvv.cpp.

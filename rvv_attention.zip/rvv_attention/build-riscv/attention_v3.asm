
build-riscv/attention_rvv_bench:     file format elf64-littleriscv


Disassembly of section .plt:

0000000000010c40 <_PROCEDURE_LINKAGE_TABLE_>:
   10c40:	97 43 00 00 33 03 c3 41 03 be 03 3b 13 03 43 fd     .C..3..A...;..C.
   10c50:	93 82 03 3b 13 53 13 00 83 b2 82 00 67 00 0e 00     ...;.S......g...

0000000000010c60 <std::__throw_length_error(char const*)@plt>:
   10c60:	00004e17          	auipc	t3,0x4
   10c64:	3a0e3e03          	ld	t3,928(t3) # 15000 <std::__throw_length_error(char const*)@GLIBCXX_3.4>
   10c68:	000e0367          	jalr	t1,t3
   10c6c:	00000013          	nop

0000000000010c70 <__libc_start_main@plt>:
   10c70:	00004e17          	auipc	t3,0x4
   10c74:	398e3e03          	ld	t3,920(t3) # 15008 <__libc_start_main@GLIBC_2.34>
   10c78:	000e0367          	jalr	t1,t3
   10c7c:	00000013          	nop

0000000000010c80 <operator new(unsigned long)@plt>:
   10c80:	00004e17          	auipc	t3,0x4
   10c84:	390e3e03          	ld	t3,912(t3) # 15010 <operator new(unsigned long)@GLIBCXX_3.4>
   10c88:	000e0367          	jalr	t1,t3
   10c8c:	00000013          	nop

0000000000010c90 <operator delete(void*, unsigned long)@plt>:
   10c90:	00004e17          	auipc	t3,0x4
   10c94:	388e3e03          	ld	t3,904(t3) # 15018 <operator delete(void*, unsigned long)@CXXABI_1.3.9>
   10c98:	000e0367          	jalr	t1,t3
   10c9c:	00000013          	nop

0000000000010ca0 <std::basic_ostream<char, std::char_traits<char> >& std::__ostream_insert<char, std::char_traits<char> >(std::basic_ostream<char, std::char_traits<char> >&, char const*, long)@plt>:
   10ca0:	00004e17          	auipc	t3,0x4
   10ca4:	380e3e03          	ld	t3,896(t3) # 15020 <std::basic_ostream<char, std::char_traits<char> >& std::__ostream_insert<char, std::char_traits<char> >(std::basic_ostream<char, std::char_traits<char> >&, char const*, long)@GLIBCXX_3.4.9>
   10ca8:	000e0367          	jalr	t1,t3
   10cac:	00000013          	nop

0000000000010cb0 <__clzdi2@plt>:
   10cb0:	00004e17          	auipc	t3,0x4
   10cb4:	378e3e03          	ld	t3,888(t3) # 15028 <__clzdi2@GCC_3.4>
   10cb8:	000e0367          	jalr	t1,t3
   10cbc:	00000013          	nop

0000000000010cc0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@plt>:
   10cc0:	00004e17          	auipc	t3,0x4
   10cc4:	370e3e03          	ld	t3,880(t3) # 15030 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@GLIBCXX_3.4.21>
   10cc8:	000e0367          	jalr	t1,t3
   10ccc:	00000013          	nop

0000000000010cd0 <memcmp@plt>:
   10cd0:	00004e17          	auipc	t3,0x4
   10cd4:	368e3e03          	ld	t3,872(t3) # 15038 <memcmp@GLIBC_2.27>
   10cd8:	000e0367          	jalr	t1,t3
   10cdc:	00000013          	nop

0000000000010ce0 <std::chrono::_V2::steady_clock::now()@plt>:
   10ce0:	00004e17          	auipc	t3,0x4
   10ce4:	360e3e03          	ld	t3,864(t3) # 15040 <std::chrono::_V2::steady_clock::now()@GLIBCXX_3.4.19>
   10ce8:	000e0367          	jalr	t1,t3
   10cec:	00000013          	nop

0000000000010cf0 <memset@plt>:
   10cf0:	00004e17          	auipc	t3,0x4
   10cf4:	358e3e03          	ld	t3,856(t3) # 15048 <memset@GLIBC_2.27>
   10cf8:	000e0367          	jalr	t1,t3
   10cfc:	00000013          	nop

0000000000010d00 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace(unsigned long, unsigned long, char const*, unsigned long)@plt>:
   10d00:	00004e17          	auipc	t3,0x4
   10d04:	350e3e03          	ld	t3,848(t3) # 15050 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace(unsigned long, unsigned long, char const*, unsigned long)@GLIBCXX_3.4.21>
   10d08:	000e0367          	jalr	t1,t3
   10d0c:	00000013          	nop

0000000000010d10 <__gxx_personality_v0@plt>:
   10d10:	00004e17          	auipc	t3,0x4
   10d14:	348e3e03          	ld	t3,840(t3) # 15058 <__gxx_personality_v0@CXXABI_1.3>
   10d18:	000e0367          	jalr	t1,t3
   10d1c:	00000013          	nop

0000000000010d20 <strtof@plt>:
   10d20:	00004e17          	auipc	t3,0x4
   10d24:	340e3e03          	ld	t3,832(t3) # 15060 <strtof@GLIBC_2.27>
   10d28:	000e0367          	jalr	t1,t3
   10d2c:	00000013          	nop

0000000000010d30 <fprintf@plt>:
   10d30:	00004e17          	auipc	t3,0x4
   10d34:	338e3e03          	ld	t3,824(t3) # 15068 <fprintf@GLIBC_2.27>
   10d38:	000e0367          	jalr	t1,t3
   10d3c:	00000013          	nop

0000000000010d40 <_Unwind_Resume@plt>:
   10d40:	00004e17          	auipc	t3,0x4
   10d44:	330e3e03          	ld	t3,816(t3) # 15070 <_Unwind_Resume@GCC_3.0>
   10d48:	000e0367          	jalr	t1,t3
   10d4c:	00000013          	nop

0000000000010d50 <printf@plt>:
   10d50:	00004e17          	auipc	t3,0x4
   10d54:	328e3e03          	ld	t3,808(t3) # 15078 <printf@GLIBC_2.27>
   10d58:	000e0367          	jalr	t1,t3
   10d5c:	00000013          	nop

0000000000010d60 <memmove@plt>:
   10d60:	00004e17          	auipc	t3,0x4
   10d64:	320e3e03          	ld	t3,800(t3) # 15080 <memmove@GLIBC_2.27>
   10d68:	000e0367          	jalr	t1,t3
   10d6c:	00000013          	nop

0000000000010d70 <__isoc23_strtol@plt>:
   10d70:	00004e17          	auipc	t3,0x4
   10d74:	318e3e03          	ld	t3,792(t3) # 15088 <__isoc23_strtol@GLIBC_2.38>
   10d78:	000e0367          	jalr	t1,t3
   10d7c:	00000013          	nop

Disassembly of section .text:

0000000000010d80 <main>:
   10d80:	b1010113          	addi	sp,sp,-1264
   10d84:	4d413023          	sd	s4,1216(sp)
   10d88:	4b613823          	sd	s6,1200(sp)
   10d8c:	4e113423          	sd	ra,1256(sp)
   10d90:	4e813023          	sd	s0,1248(sp)
   10d94:	4c913c23          	sd	s1,1240(sp)
   10d98:	4d213823          	sd	s2,1232(sp)
   10d9c:	4d313423          	sd	s3,1224(sp)
   10da0:	4b513c23          	sd	s5,1208(sp)
   10da4:	4b713423          	sd	s7,1192(sp)
   10da8:	4b813023          	sd	s8,1184(sp)
   10dac:	49913c23          	sd	s9,1176(sp)
   10db0:	49a13823          	sd	s10,1168(sp)
   10db4:	49b13423          	sd	s11,1160(sp)
   10db8:	46813c27          	fsd	fs0,1144(sp)
   10dbc:	46913827          	fsd	fs1,1136(sp)
   10dc0:	47213427          	fsd	fs2,1128(sp)
   10dc4:	80010113          	addi	sp,sp,-2048
   10dc8:	80010113          	addi	sp,sp,-2048
   10dcc:	01bc                	addi	a5,sp,200
   10dce:	fd3e                	sd	a5,184(sp)
   10dd0:	0c010423          	sb	zero,200(sp)
   10dd4:	e182                	sd	zero,192(sp)
   10dd6:	4a05                	li	s4,1
   10dd8:	8b2e                	mv	s6,a1
   10dda:	28aa5ee3          	bge	s4,a0,11876 <main+0xaf6>
   10dde:	67d5                	lui	a5,0x15
   10de0:	0987a407          	flw	fs0,152(a5) # 15098 <__TMC_END__+0x8>
   10de4:	06400793          	li	a5,100
   10de8:	f83e                	sd	a5,48(sp)
   10dea:	57fd                	li	a5,-1
   10dec:	8aaa                	mv	s5,a0
   10dee:	e482                	sd	zero,72(sp)
   10df0:	4d29                	li	s10,10
   10df2:	fc3e                	sd	a5,56(sp)
   10df4:	6bcd                	lui	s7,0x13
   10df6:	6c4d                	lui	s8,0x13
   10df8:	64cd                	lui	s1,0x13
   10dfa:	694d                	lui	s2,0x13
   10dfc:	003a1593          	slli	a1,s4,0x3
   10e00:	95da                	add	a1,a1,s6
   10e02:	6198                	ld	a4,0(a1)
   10e04:	d08b8693          	addi	a3,s7,-760 # 12d08 <_IO_stdin_used+0xa8>
   10e08:	4781                	li	a5,0
   10e0a:	863a                	mv	a2,a4
   10e0c:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   10e10:	963e                	add	a2,a2,a5
   10e12:	03060087          	vle8ff.v	v1,(a2)
   10e16:	96be                	add	a3,a3,a5
   10e18:	03068107          	vle8ff.v	v2,(a3)
   10e1c:	66110157          	vmsne.vv	v2,v1,v2
   10e20:	621030d7          	vmseq.vi	v1,v1,0
   10e24:	c20027f3          	csrr	a5,vl
   10e28:	6a1120d7          	vmor.mm	v1,v1,v2
   10e2c:	4218a557          	vfirst.m	a0,v1
   10e30:	fc054ee3          	bltz	a0,10e0c <main+0x8c>
   10e34:	962a                	add	a2,a2,a0
   10e36:	96aa                	add	a3,a3,a0
   10e38:	00064603          	lbu	a2,0(a2)
   10e3c:	0006c783          	lbu	a5,0(a3)
   10e40:	00f61663          	bne	a2,a5,10e4c <main+0xcc>
   10e44:	001a0c9b          	addiw	s9,s4,1
   10e48:	275cc963          	blt	s9,s5,110ba <main+0x33a>
   10e4c:	863a                	mv	a2,a4
   10e4e:	d10c0693          	addi	a3,s8,-752 # 12d10 <_IO_stdin_used+0xb0>
   10e52:	4781                	li	a5,0
   10e54:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   10e58:	963e                	add	a2,a2,a5
   10e5a:	03060087          	vle8ff.v	v1,(a2)
   10e5e:	96be                	add	a3,a3,a5
   10e60:	03068107          	vle8ff.v	v2,(a3)
   10e64:	66110157          	vmsne.vv	v2,v1,v2
   10e68:	621030d7          	vmseq.vi	v1,v1,0
   10e6c:	c20027f3          	csrr	a5,vl
   10e70:	6a1120d7          	vmor.mm	v1,v1,v2
   10e74:	4218a557          	vfirst.m	a0,v1
   10e78:	fc054ee3          	bltz	a0,10e54 <main+0xd4>
   10e7c:	962a                	add	a2,a2,a0
   10e7e:	96aa                	add	a3,a3,a0
   10e80:	00064603          	lbu	a2,0(a2)
   10e84:	0006c783          	lbu	a5,0(a3)
   10e88:	00f61663          	bne	a2,a5,10e94 <main+0x114>
   10e8c:	001a0c9b          	addiw	s9,s4,1
   10e90:	255ccf63          	blt	s9,s5,110ee <main+0x36e>
   10e94:	863a                	mv	a2,a4
   10e96:	d1848693          	addi	a3,s1,-744 # 12d18 <_IO_stdin_used+0xb8>
   10e9a:	4781                	li	a5,0
   10e9c:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   10ea0:	963e                	add	a2,a2,a5
   10ea2:	03060087          	vle8ff.v	v1,(a2)
   10ea6:	96be                	add	a3,a3,a5
   10ea8:	03068107          	vle8ff.v	v2,(a3)
   10eac:	66110157          	vmsne.vv	v2,v1,v2
   10eb0:	621030d7          	vmseq.vi	v1,v1,0
   10eb4:	c20027f3          	csrr	a5,vl
   10eb8:	6a1120d7          	vmor.mm	v1,v1,v2
   10ebc:	4218a557          	vfirst.m	a0,v1
   10ec0:	fc054ee3          	bltz	a0,10e9c <main+0x11c>
   10ec4:	962a                	add	a2,a2,a0
   10ec6:	96aa                	add	a3,a3,a0
   10ec8:	00064603          	lbu	a2,0(a2)
   10ecc:	0006c783          	lbu	a5,0(a3)
   10ed0:	00f61663          	bne	a2,a5,10edc <main+0x15c>
   10ed4:	001a0c9b          	addiw	s9,s4,1
   10ed8:	235cc563          	blt	s9,s5,11102 <main+0x382>
   10edc:	863a                	mv	a2,a4
   10ede:	d2890693          	addi	a3,s2,-728 # 12d28 <_IO_stdin_used+0xc8>
   10ee2:	4781                	li	a5,0
   10ee4:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   10ee8:	963e                	add	a2,a2,a5
   10eea:	03060087          	vle8ff.v	v1,(a2)
   10eee:	96be                	add	a3,a3,a5
   10ef0:	03068107          	vle8ff.v	v2,(a3)
   10ef4:	66110157          	vmsne.vv	v2,v1,v2
   10ef8:	621030d7          	vmseq.vi	v1,v1,0
   10efc:	c20027f3          	csrr	a5,vl
   10f00:	6a1120d7          	vmor.mm	v1,v1,v2
   10f04:	4218a557          	vfirst.m	a0,v1
   10f08:	fc054ee3          	bltz	a0,10ee4 <main+0x164>
   10f0c:	962a                	add	a2,a2,a0
   10f0e:	96aa                	add	a3,a3,a0
   10f10:	00064603          	lbu	a2,0(a2)
   10f14:	0006c783          	lbu	a5,0(a3)
   10f18:	10f61063          	bne	a2,a5,11018 <main+0x298>
   10f1c:	001a0c9b          	addiw	s9,s4,1
   10f20:	1f5cca63          	blt	s9,s5,11114 <main+0x394>
   10f24:	67cd                	lui	a5,0x13
   10f26:	d3878793          	addi	a5,a5,-712 # 12d38 <_IO_stdin_used+0xd8>
   10f2a:	863a                	mv	a2,a4
   10f2c:	4681                	li	a3,0
   10f2e:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   10f32:	9636                	add	a2,a2,a3
   10f34:	03060087          	vle8ff.v	v1,(a2)
   10f38:	97b6                	add	a5,a5,a3
   10f3a:	03078107          	vle8ff.v	v2,(a5)
   10f3e:	66110157          	vmsne.vv	v2,v1,v2
   10f42:	621030d7          	vmseq.vi	v1,v1,0
   10f46:	c20026f3          	csrr	a3,vl
   10f4a:	6a1120d7          	vmor.mm	v1,v1,v2
   10f4e:	4218a5d7          	vfirst.m	a1,v1
   10f52:	fc05cee3          	bltz	a1,10f2e <main+0x1ae>
   10f56:	962e                	add	a2,a2,a1
   10f58:	97ae                	add	a5,a5,a1
   10f5a:	00064683          	lbu	a3,0(a2)
   10f5e:	0007c783          	lbu	a5,0(a5)
   10f62:	10f69963          	bne	a3,a5,11074 <main+0x2f4>
   10f66:	67cd                	lui	a5,0x13
   10f68:	d4078793          	addi	a5,a5,-704 # 12d40 <_IO_stdin_used+0xe0>
   10f6c:	4681                	li	a3,0
   10f6e:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   10f72:	9736                	add	a4,a4,a3
   10f74:	03070087          	vle8ff.v	v1,(a4)
   10f78:	97b6                	add	a5,a5,a3
   10f7a:	03078107          	vle8ff.v	v2,(a5)
   10f7e:	66110157          	vmsne.vv	v2,v1,v2
   10f82:	621030d7          	vmseq.vi	v1,v1,0
   10f86:	c20026f3          	csrr	a3,vl
   10f8a:	6a1120d7          	vmor.mm	v1,v1,v2
   10f8e:	4218a657          	vfirst.m	a2,v1
   10f92:	fc064ee3          	bltz	a2,10f6e <main+0x1ee>
   10f96:	9732                	add	a4,a4,a2
   10f98:	97b2                	add	a5,a5,a2
   10f9a:	00074703          	lbu	a4,0(a4)
   10f9e:	0007c783          	lbu	a5,0(a5)
   10fa2:	18f70363          	beq	a4,a5,11128 <main+0x3a8>
   10fa6:	67d5                	lui	a5,0x15
   10fa8:	000b3603          	ld	a2,0(s6)
   10fac:	0c07b503          	ld	a0,192(a5) # 150c0 <stderr@GLIBC_2.27>
   10fb0:	65cd                	lui	a1,0x13
   10fb2:	d4858593          	addi	a1,a1,-696 # 12d48 <_IO_stdin_used+0xe8>
   10fb6:	d7bff0ef          	jal	10d30 <fprintf@plt>
   10fba:	4909                	li	s2,2
   10fbc:	756a                	ld	a0,184(sp)
   10fbe:	01bc                	addi	a5,sp,200
   10fc0:	00f50663          	beq	a0,a5,10fcc <main+0x24c>
   10fc4:	65ae                	ld	a1,200(sp)
   10fc6:	0585                	addi	a1,a1,1
   10fc8:	cc9ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   10fcc:	6285                	lui	t0,0x1
   10fce:	9116                	add	sp,sp,t0
   10fd0:	4e813083          	ld	ra,1256(sp)
   10fd4:	854a                	mv	a0,s2
   10fd6:	4e013403          	ld	s0,1248(sp)
   10fda:	4d813483          	ld	s1,1240(sp)
   10fde:	4d013903          	ld	s2,1232(sp)
   10fe2:	4c813983          	ld	s3,1224(sp)
   10fe6:	4c013a03          	ld	s4,1216(sp)
   10fea:	4b813a83          	ld	s5,1208(sp)
   10fee:	4b013b03          	ld	s6,1200(sp)
   10ff2:	4a813b83          	ld	s7,1192(sp)
   10ff6:	4a013c03          	ld	s8,1184(sp)
   10ffa:	49813c83          	ld	s9,1176(sp)
   10ffe:	49013d03          	ld	s10,1168(sp)
   11002:	48813d83          	ld	s11,1160(sp)
   11006:	47813407          	fld	fs0,1144(sp)
   1100a:	47013487          	fld	fs1,1136(sp)
   1100e:	46813907          	fld	fs2,1128(sp)
   11012:	4f010113          	addi	sp,sp,1264
   11016:	8082                	ret
   11018:	67cd                	lui	a5,0x13
   1101a:	d3878793          	addi	a5,a5,-712 # 12d38 <_IO_stdin_used+0xd8>
   1101e:	863a                	mv	a2,a4
   11020:	4681                	li	a3,0
   11022:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   11026:	9636                	add	a2,a2,a3
   11028:	03060087          	vle8ff.v	v1,(a2)
   1102c:	97b6                	add	a5,a5,a3
   1102e:	03078107          	vle8ff.v	v2,(a5)
   11032:	66110157          	vmsne.vv	v2,v1,v2
   11036:	621030d7          	vmseq.vi	v1,v1,0
   1103a:	c20026f3          	csrr	a3,vl
   1103e:	6a1120d7          	vmor.mm	v1,v1,v2
   11042:	4218a557          	vfirst.m	a0,v1
   11046:	fc054ee3          	bltz	a0,11022 <main+0x2a2>
   1104a:	962a                	add	a2,a2,a0
   1104c:	97aa                	add	a5,a5,a0
   1104e:	00064683          	lbu	a3,0(a2)
   11052:	0007c783          	lbu	a5,0(a5)
   11056:	00f69f63          	bne	a3,a5,11074 <main+0x2f4>
   1105a:	2a05                	addiw	s4,s4,1
   1105c:	f15a55e3          	bge	s4,s5,10f66 <main+0x1e6>
   11060:	6588                	ld	a0,8(a1)
   11062:	4581                	li	a1,0
   11064:	cbdff0ef          	jal	10d20 <strtof@plt>
   11068:	20a50453          	fmv.s	fs0,fa0
   1106c:	2a05                	addiw	s4,s4,1
   1106e:	d95a47e3          	blt	s4,s5,10dfc <main+0x7c>
   11072:	a86d                	j	1112c <main+0x3ac>
   11074:	67cd                	lui	a5,0x13
   11076:	d4078793          	addi	a5,a5,-704 # 12d40 <_IO_stdin_used+0xe0>
   1107a:	4681                	li	a3,0
   1107c:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   11080:	9736                	add	a4,a4,a3
   11082:	03070087          	vle8ff.v	v1,(a4)
   11086:	97b6                	add	a5,a5,a3
   11088:	03078107          	vle8ff.v	v2,(a5)
   1108c:	66110157          	vmsne.vv	v2,v1,v2
   11090:	621030d7          	vmseq.vi	v1,v1,0
   11094:	c20026f3          	csrr	a3,vl
   11098:	6a1120d7          	vmor.mm	v1,v1,v2
   1109c:	4218a657          	vfirst.m	a2,v1
   110a0:	fc064ee3          	bltz	a2,1107c <main+0x2fc>
   110a4:	9732                	add	a4,a4,a2
   110a6:	97b2                	add	a5,a5,a2
   110a8:	00074703          	lbu	a4,0(a4)
   110ac:	0007c783          	lbu	a5,0(a5)
   110b0:	eef71be3          	bne	a4,a5,10fa6 <main+0x226>
   110b4:	4785                	li	a5,1
   110b6:	e4be                	sd	a5,72(sp)
   110b8:	bf55                	j	1106c <main+0x2ec>
   110ba:	6594                	ld	a3,8(a1)
   110bc:	4701                	li	a4,0
   110be:	87b6                	mv	a5,a3
   110c0:	0c007457          	vsetvli	s0,zero,e8,m1,ta,ma
   110c4:	97ba                	add	a5,a5,a4
   110c6:	03078087          	vle8ff.v	v1,(a5)
   110ca:	621030d7          	vmseq.vi	v1,v1,0
   110ce:	c2002773          	csrr	a4,vl
   110d2:	4218a657          	vfirst.m	a2,v1
   110d6:	fe0645e3          	bltz	a2,110c0 <main+0x340>
   110da:	97b2                	add	a5,a5,a2
   110dc:	660e                	ld	a2,192(sp)
   110de:	40d78733          	sub	a4,a5,a3
   110e2:	1928                	addi	a0,sp,184
   110e4:	4581                	li	a1,0
   110e6:	c1bff0ef          	jal	10d00 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace(unsigned long, unsigned long, char const*, unsigned long)@plt>
   110ea:	8a66                	mv	s4,s9
   110ec:	b741                	j	1106c <main+0x2ec>
   110ee:	6588                	ld	a0,8(a1)
   110f0:	4629                	li	a2,10
   110f2:	4581                	li	a1,0
   110f4:	c7dff0ef          	jal	10d70 <__isoc23_strtol@plt>
   110f8:	0005079b          	sext.w	a5,a0
   110fc:	8a66                	mv	s4,s9
   110fe:	fc3e                	sd	a5,56(sp)
   11100:	b7b5                	j	1106c <main+0x2ec>
   11102:	6588                	ld	a0,8(a1)
   11104:	4629                	li	a2,10
   11106:	4581                	li	a1,0
   11108:	c69ff0ef          	jal	10d70 <__isoc23_strtol@plt>
   1110c:	8a66                	mv	s4,s9
   1110e:	00050d1b          	sext.w	s10,a0
   11112:	bfa9                	j	1106c <main+0x2ec>
   11114:	6588                	ld	a0,8(a1)
   11116:	4629                	li	a2,10
   11118:	4581                	li	a1,0
   1111a:	c57ff0ef          	jal	10d70 <__isoc23_strtol@plt>
   1111e:	0005079b          	sext.w	a5,a0
   11122:	8a66                	mv	s4,s9
   11124:	f83e                	sd	a5,48(sp)
   11126:	b799                	j	1106c <main+0x2ec>
   11128:	4785                	li	a5,1
   1112a:	e4be                	sd	a5,72(sp)
   1112c:	660e                	ld	a2,192(sp)
   1112e:	4709                	li	a4,2
   11130:	0ae60963          	beq	a2,a4,111e2 <main+0x462>
   11134:	65cd                	lui	a1,0x13
   11136:	1928                	addi	a0,sp,184
   11138:	e3058593          	addi	a1,a1,-464 # 12e30 <_IO_stdin_used+0x1d0>
   1113c:	233010ef          	jal	12b6e <bool std::operator==<char, std::char_traits<char>, std::allocator<char> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)>
   11140:	e60503e3          	beqz	a0,10fa6 <main+0x226>
   11144:	4701                	li	a4,0
   11146:	7962                	ld	s2,56(sp)
   11148:	01fd569b          	srliw	a3,s10,0x1f
   1114c:	00192793          	slti	a5,s2,1
   11150:	8fd5                	or	a5,a5,a3
   11152:	e4079ae3          	bnez	a5,10fa6 <main+0x226>
   11156:	77c2                	ld	a5,48(sp)
   11158:	e4f057e3          	blez	a5,10fa6 <main+0x226>
   1115c:	f00007d3          	fmv.w.x	fa5,zero
   11160:	a0f417d3          	flt.s	a5,fs0,fa5
   11164:	e40791e3          	bnez	a5,10fa6 <main+0x226>
   11168:	c319                	beqz	a4,1116e <main+0x3ee>
   1116a:	04000913          	li	s2,64
   1116e:	65cd                	lui	a1,0x13
   11170:	1928                	addi	a0,sp,184
   11172:	e2858593          	addi	a1,a1,-472 # 12e28 <_IO_stdin_used+0x1c8>
   11176:	1f9010ef          	jal	12b6e <bool std::operator==<char, std::char_traits<char>, std::allocator<char> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)>
   1117a:	04000993          	li	s3,64
   1117e:	38051a63          	bnez	a0,11512 <main+0x792>
   11182:	47e1                	li	a5,24
   11184:	02f90ab3          	mul	s5,s2,a5
   11188:	4419                	li	s0,6
   1118a:	03390a33          	mul	s4,s2,s3
   1118e:	8556                	mv	a0,s5
   11190:	ecd6                	sd	s5,88(sp)
   11192:	028a0433          	mul	s0,s4,s0
   11196:	aebff0ef          	jal	10c80 <operator new(unsigned long)@plt>
   1119a:	00052023          	sw	zero,0(a0)
   1119e:	84aa                	mv	s1,a0
   111a0:	ffca8613          	addi	a2,s5,-4
   111a4:	0511                	addi	a0,a0,4
   111a6:	4581                	li	a1,0
   111a8:	b49ff0ef          	jal	10cf0 <memset@plt>
   111ac:	57fd                	li	a5,-1
   111ae:	838d                	srli	a5,a5,0x3
   111b0:	7287e563          	bltu	a5,s0,118da <main+0xb5a>
   111b4:	47e1                	li	a5,24
   111b6:	02fa0a33          	mul	s4,s4,a5
   111ba:	f4d2                	sd	s4,104(sp)
   111bc:	cc05                	beqz	s0,111f4 <main+0x474>
   111be:	8552                	mv	a0,s4
   111c0:	ac1ff0ef          	jal	10c80 <operator new(unsigned long)@plt>
   111c4:	8752                	mv	a4,s4
   111c6:	842a                	mv	s0,a0
   111c8:	1a71                	addi	s4,s4,-4
   111ca:	00052023          	sw	zero,0(a0)
   111ce:	8652                	mv	a2,s4
   111d0:	00e407b3          	add	a5,s0,a4
   111d4:	0511                	addi	a0,a0,4
   111d6:	4581                	li	a1,0
   111d8:	f0be                	sd	a5,96(sp)
   111da:	b17ff0ef          	jal	10cf0 <memset@plt>
   111de:	9a2a                	add	s4,s4,a0
   111e0:	a829                	j	111fa <main+0x47a>
   111e2:	756a                	ld	a0,184(sp)
   111e4:	65cd                	lui	a1,0x13
   111e6:	e2858593          	addi	a1,a1,-472 # 12e28 <_IO_stdin_used+0x1c8>
   111ea:	ae7ff0ef          	jal	10cd0 <memcmp@plt>
   111ee:	f139                	bnez	a0,11134 <main+0x3b4>
   111f0:	4705                	li	a4,1
   111f2:	bf91                	j	11146 <main+0x3c6>
   111f4:	77a6                	ld	a5,104(sp)
   111f6:	4a01                	li	s4,0
   111f8:	f0be                	sd	a5,96(sp)
   111fa:	47e1                	li	a5,24
   111fc:	02f98bb3          	mul	s7,s3,a5
   11200:	67e6                	ld	a5,88(sp)
   11202:	00f48b33          	add	s6,s1,a5
   11206:	855e                	mv	a0,s7
   11208:	e8de                	sd	s7,80(sp)
   1120a:	a77ff0ef          	jal	10c80 <operator new(unsigned long)@plt>
   1120e:	e0aa                	sd	a0,64(sp)
   11210:	00052023          	sw	zero,0(a0)
   11214:	ffcb8613          	addi	a2,s7,-4
   11218:	0511                	addi	a0,a0,4
   1121a:	4581                	li	a1,0
   1121c:	ad5ff0ef          	jal	10cf0 <memset@plt>
   11220:	855e                	mv	a0,s7
   11222:	a5fff0ef          	jal	10c80 <operator new(unsigned long)@plt>
   11226:	00052023          	sw	zero,0(a0)
   1122a:	ffcb8613          	addi	a2,s7,-4
   1122e:	4581                	li	a1,0
   11230:	8daa                	mv	s11,a0
   11232:	0511                	addi	a0,a0,4
   11234:	abdff0ef          	jal	10cf0 <memset@plt>
   11238:	678d                	lui	a5,0x3
   1123a:	03978793          	addi	a5,a5,57 # 3039 <_PROCEDURE_LINKAGE_TABLE_-0xdc07>
   1123e:	0d810313          	addi	t1,sp,216
   11242:	6c0795b7          	lui	a1,0x6c079
   11246:	edbe                	sd	a5,216(sp)
   11248:	00830613          	addi	a2,t1,8
   1124c:	96558593          	addi	a1,a1,-1691 # 6c078965 <__BSS_END__+0x6c053765>
   11250:	4685                	li	a3,1
   11252:	27000513          	li	a0,624
   11256:	873e                	mv	a4,a5
   11258:	01e75793          	srli	a5,a4,0x1e
   1125c:	8fb9                	xor	a5,a5,a4
   1125e:	02b787b3          	mul	a5,a5,a1
   11262:	0621                	addi	a2,a2,8
   11264:	97b6                	add	a5,a5,a3
   11266:	02079713          	slli	a4,a5,0x20
   1126a:	9301                	srli	a4,a4,0x20
   1126c:	fee63c23          	sd	a4,-8(a2)
   11270:	0685                	addi	a3,a3,1
   11272:	fea693e3          	bne	a3,a0,11258 <main+0x4d8>
   11276:	00099f37          	lui	t5,0x99
   1127a:	0d8077d7          	vsetvli	a5,zero,e64,m1,ta,ma
   1127e:	08bf0f13          	addi	t5,t5,139 # 9908b <__BSS_END__+0x73e8b>
   11282:	6bd5                	lui	s7,0x15
   11284:	6c55                	lui	s8,0x15
   11286:	6cd5                	lui	s9,0x15
   11288:	80000fb7          	lui	t6,0x80000
   1128c:	0f32                	slli	t5,t5,0xc
   1128e:	6785                	lui	a5,0x1
   11290:	09cba687          	flw	fa3,156(s7) # 1509c <__TMC_END__+0xc>
   11294:	0a0c2707          	flw	fa4,160(s8) # 150a0 <__TMC_END__+0x10>
   11298:	0a4ca587          	flw	fa1,164(s9) # 150a4 <__TMC_END__+0x14>
   1129c:	6755                	lui	a4,0x15
   1129e:	0dff0f13          	addi	t5,t5,223
   112a2:	ffffca93          	not	s5,t6
   112a6:	37878793          	addi	a5,a5,888 # 1378 <_PROCEDURE_LINKAGE_TABLE_-0xf8c8>
   112aa:	5e0f44d7          	vmv.v.x	v9,t5
   112ae:	5e0ac457          	vmv.v.x	v8,s5
   112b2:	5e0fc3d7          	vmv.v.x	v7,t6
   112b6:	0a872607          	flw	fa2,168(a4) # 150a8 <__TMC_END__+0x18>
   112ba:	979a                	add	a5,a5,t1
   112bc:	46010e13          	addi	t3,sp,1120
   112c0:	8726                	mv	a4,s1
   112c2:	27000e93          	li	t4,624
   112c6:	f8ea                	sd	s10,112(sp)
   112c8:	864a                	mv	a2,s2
   112ca:	cd817057          	vsetivli	zero,2,e64,m1,ta,ma
   112ce:	013a6937          	lui	s2,0x13a6
   112d2:	5e0ac357          	vmv.v.x	v6,s5
   112d6:	5e0fc2d7          	vmv.v.x	v5,t6
   112da:	5e0f4257          	vmv.v.x	v4,t5
   112de:	8ad90913          	addi	s2,s2,-1875 # 13a58ad <__BSS_END__+0x13806ad>
   112e2:	077e3d37          	lui	s10,0x77e3
   112e6:	85b6                	mv	a1,a3
   112e8:	091e                	slli	s2,s2,0x7
   112ea:	0d16                	slli	s10,s10,0x5
   112ec:	86b2                	mv	a3,a2
   112ee:	31d58763          	beq	a1,t4,115fc <main+0x87c>
   112f2:	00359613          	slli	a2,a1,0x3
   112f6:	9672                	add	a2,a2,t3
   112f8:	c7863503          	ld	a0,-904(a2)
   112fc:	0585                	addi	a1,a1,1
   112fe:	01551813          	slli	a6,a0,0x15
   11302:	02085613          	srli	a2,a6,0x20
   11306:	8e29                	xor	a2,a2,a0
   11308:	00761513          	slli	a0,a2,0x7
   1130c:	01257533          	and	a0,a0,s2
   11310:	8e29                	xor	a2,a2,a0
   11312:	00f61513          	slli	a0,a2,0xf
   11316:	01a57533          	and	a0,a0,s10
   1131a:	8e29                	xor	a2,a2,a0
   1131c:	01265513          	srli	a0,a2,0x12
   11320:	8e29                	xor	a2,a2,a0
   11322:	d01677d3          	fcvt.s.wu	fa5,a2
   11326:	10d7f7d3          	fmul.s	fa5,fa5,fa3
   1132a:	a0e79653          	flt.s	a2,fa5,fa4
   1132e:	d261                	beqz	a2,112ee <main+0x56e>
   11330:	60b7f7c3          	fmadd.s	fa5,fa5,fa1,fa2
   11334:	0711                	addi	a4,a4,4
   11336:	8636                	mv	a2,a3
   11338:	86ae                	mv	a3,a1
   1133a:	fef72e27          	fsw	fa5,-4(a4)
   1133e:	f8eb18e3          	bne	s6,a4,112ce <main+0x54e>
   11342:	7d46                	ld	s10,112(sp)
   11344:	8932                	mv	s2,a2
   11346:	0a8a0f63          	beq	s4,s0,11404 <main+0x684>
   1134a:	00099fb7          	lui	t6,0x99
   1134e:	0d8077d7          	vsetvli	a5,zero,e64,m1,ta,ma
   11352:	08bf8f93          	addi	t6,t6,139 # 9908b <__BSS_END__+0x73e8b>
   11356:	800002b7          	lui	t0,0x80000
   1135a:	0fb2                	slli	t6,t6,0xc
   1135c:	6785                	lui	a5,0x1
   1135e:	09cba687          	flw	fa3,156(s7)
   11362:	0a0c2707          	flw	fa4,160(s8)
   11366:	0a4ca587          	flw	fa1,164(s9)
   1136a:	6755                	lui	a4,0x15
   1136c:	0dff8f93          	addi	t6,t6,223
   11370:	fff2ca93          	not	s5,t0
   11374:	37878793          	addi	a5,a5,888 # 1378 <_PROCEDURE_LINKAGE_TABLE_-0xf8c8>
   11378:	5e0fc4d7          	vmv.v.x	v9,t6
   1137c:	5e0ac457          	vmv.v.x	v8,s5
   11380:	5e02c3d7          	vmv.v.x	v7,t0
   11384:	0a872607          	flw	fa2,168(a4) # 150a8 <__TMC_END__+0x18>
   11388:	979a                	add	a5,a5,t1
   1138a:	46010e93          	addi	t4,sp,1120
   1138e:	8722                	mv	a4,s0
   11390:	27000f13          	li	t5,624
   11394:	cd817057          	vsetivli	zero,2,e64,m1,ta,ma
   11398:	013a6b37          	lui	s6,0x13a6
   1139c:	5e0ac357          	vmv.v.x	v6,s5
   113a0:	5e02c2d7          	vmv.v.x	v5,t0
   113a4:	5e0fc257          	vmv.v.x	v4,t6
   113a8:	8adb0b13          	addi	s6,s6,-1875 # 13a58ad <__BSS_END__+0x13806ad>
   113ac:	077e3bb7          	lui	s7,0x77e3
   113b0:	0b1e                	slli	s6,s6,0x7
   113b2:	0b96                	slli	s7,s7,0x5
   113b4:	17e68163          	beq	a3,t5,11516 <main+0x796>
   113b8:	00369613          	slli	a2,a3,0x3
   113bc:	9676                	add	a2,a2,t4
   113be:	c7863583          	ld	a1,-904(a2)
   113c2:	0685                	addi	a3,a3,1
   113c4:	01559513          	slli	a0,a1,0x15
   113c8:	02055613          	srli	a2,a0,0x20
   113cc:	8e2d                	xor	a2,a2,a1
   113ce:	00761593          	slli	a1,a2,0x7
   113d2:	0165f5b3          	and	a1,a1,s6
   113d6:	8e2d                	xor	a2,a2,a1
   113d8:	00f61593          	slli	a1,a2,0xf
   113dc:	0175f5b3          	and	a1,a1,s7
   113e0:	8e2d                	xor	a2,a2,a1
   113e2:	01265593          	srli	a1,a2,0x12
   113e6:	8e2d                	xor	a2,a2,a1
   113e8:	d01677d3          	fcvt.s.wu	fa5,a2
   113ec:	10d7f7d3          	fmul.s	fa5,fa5,fa3
   113f0:	a0e79653          	flt.s	a2,fa5,fa4
   113f4:	d261                	beqz	a2,113b4 <main+0x634>
   113f6:	60b7f7c3          	fmadd.s	fa5,fa5,fa1,fa2
   113fa:	0711                	addi	a4,a4,4
   113fc:	fef72e27          	fsw	fa5,-4(a4)
   11400:	f8ea1ce3          	bne	s4,a4,11398 <main+0x618>
   11404:	6a06                	ld	s4,64(sp)
   11406:	884e                	mv	a6,s3
   11408:	87ca                	mv	a5,s2
   1140a:	4705                	li	a4,1
   1140c:	4699                	li	a3,6
   1140e:	8652                	mv	a2,s4
   11410:	85a2                	mv	a1,s0
   11412:	8526                	mv	a0,s1
   11414:	5d8000ef          	jal	119ec <attention_bmm_rvv_baseline_f32>
   11418:	884e                	mv	a6,s3
   1141a:	87ca                	mv	a5,s2
   1141c:	4705                	li	a4,1
   1141e:	4699                	li	a3,6
   11420:	866e                	mv	a2,s11
   11422:	85a2                	mv	a1,s0
   11424:	8526                	mv	a0,s1
   11426:	1b0010ef          	jal	125d6 <attention_bmm_rvv_f32>
   1142a:	66c6                	ld	a3,80(sp)
   1142c:	f0000753          	fmv.w.x	fa4,zero
   11430:	87d2                	mv	a5,s4
   11432:	00da0633          	add	a2,s4,a3
   11436:	876e                	mv	a4,s11
   11438:	0007a787          	flw	fa5,0(a5)
   1143c:	00072687          	flw	fa3,0(a4)
   11440:	20e704d3          	fmv.s	fs1,fa4
   11444:	08d7f7d3          	fsub.s	fa5,fa5,fa3
   11448:	20f7a7d3          	fabs.s	fa5,fa5
   1144c:	a0f716d3          	flt.s	a3,fa4,fa5
   11450:	c299                	beqz	a3,11456 <main+0x6d6>
   11452:	20f784d3          	fmv.s	fs1,fa5
   11456:	0791                	addi	a5,a5,4
   11458:	20948753          	fmv.s	fa4,fs1
   1145c:	0711                	addi	a4,a4,4
   1145e:	fcf61de3          	bne	a2,a5,11438 <main+0x6b8>
   11462:	a09417d3          	flt.s	a5,fs0,fs1
   11466:	42079363          	bnez	a5,1188c <main+0xb0c>
   1146a:	4a01                	li	s4,0
   1146c:	000d0e63          	beqz	s10,11488 <main+0x708>
   11470:	6606                	ld	a2,64(sp)
   11472:	884e                	mv	a6,s3
   11474:	87ca                	mv	a5,s2
   11476:	4705                	li	a4,1
   11478:	4699                	li	a3,6
   1147a:	85a2                	mv	a1,s0
   1147c:	8526                	mv	a0,s1
   1147e:	56e000ef          	jal	119ec <attention_bmm_rvv_baseline_f32>
   11482:	2a05                	addiw	s4,s4,1
   11484:	ff4d16e3          	bne	s10,s4,11470 <main+0x6f0>
   11488:	77c2                	ld	a5,48(sp)
   1148a:	00379a13          	slli	s4,a5,0x3
   1148e:	8552                	mv	a0,s4
   11490:	f8d2                	sd	s4,112(sp)
   11492:	feeff0ef          	jal	10c80 <operator new(unsigned long)@plt>
   11496:	67d5                	lui	a5,0x15
   11498:	01450bb3          	add	s7,a0,s4
   1149c:	8b26                	mv	s6,s1
   1149e:	0907b407          	fld	fs0,144(a5) # 15090 <__TMC_END__>
   114a2:	8caa                	mv	s9,a0
   114a4:	8aaa                	mv	s5,a0
   114a6:	46010a13          	addi	s4,sp,1120
   114aa:	4c01                	li	s8,0
   114ac:	fcee                	sd	s11,120(sp)
   114ae:	84a2                	mv	s1,s0
   114b0:	a801                	j	114c0 <main+0x740>
   114b2:	00fcb027          	fsd	fa5,0(s9)
   114b6:	0ca1                	addi	s9,s9,8
   114b8:	77c2                	ld	a5,48(sp)
   114ba:	2c05                	addiw	s8,s8,1
   114bc:	22fc5763          	bge	s8,a5,116ea <main+0x96a>
   114c0:	821ff0ef          	jal	10ce0 <std::chrono::_V2::steady_clock::now()@plt>
   114c4:	6606                	ld	a2,64(sp)
   114c6:	842a                	mv	s0,a0
   114c8:	884e                	mv	a6,s3
   114ca:	87ca                	mv	a5,s2
   114cc:	85a6                	mv	a1,s1
   114ce:	855a                	mv	a0,s6
   114d0:	4705                	li	a4,1
   114d2:	4699                	li	a3,6
   114d4:	518000ef          	jal	119ec <attention_bmm_rvv_baseline_f32>
   114d8:	809ff0ef          	jal	10ce0 <std::chrono::_V2::steady_clock::now()@plt>
   114dc:	408507b3          	sub	a5,a0,s0
   114e0:	d227f7d3          	fcvt.d.l	fa5,a5
   114e4:	1a87f7d3          	fdiv.d	fa5,fa5,fs0
   114e8:	c4fa3027          	fsd	fa5,-960(s4)
   114ec:	fd7c93e3          	bne	s9,s7,114b2 <main+0x732>
   114f0:	0128                	addi	a0,sp,136
   114f2:	110c                	addi	a1,sp,160
   114f4:	c35a3423          	sd	s5,-984(s4)
   114f8:	c39a3823          	sd	s9,-976(s4)
   114fc:	c39a3c23          	sd	s9,-968(s4)
   11500:	6b6010ef          	jal	12bb6 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)>
   11504:	c28a3a83          	ld	s5,-984(s4)
   11508:	c30a3c83          	ld	s9,-976(s4)
   1150c:	c38a3b83          	ld	s7,-968(s4)
   11510:	b765                	j	114b8 <main+0x738>
   11512:	79e2                	ld	s3,56(sp)
   11514:	b1bd                	j	11182 <main+0x402>
   11516:	09ac                	addi	a1,sp,216
   11518:	54110813          	addi	a6,sp,1345
   1151c:	7ff80813          	addi	a6,a6,2047
   11520:	0e010e13          	addi	t3,sp,224
   11524:	88ae                	mv	a7,a1
   11526:	0e300513          	li	a0,227
   1152a:	0d8576d7          	vsetvli	a3,a0,e64,m1,ta,ma
   1152e:	020e7087          	vle64.v	v1,(t3)
   11532:	0208f107          	vle64.v	v2,(a7)
   11536:	02087187          	vle64.v	v3,(a6)
   1153a:	00369613          	slli	a2,a3,0x3
   1153e:	8d15                	sub	a0,a0,a3
   11540:	9832                	add	a6,a6,a2
   11542:	261400d7          	vand.vv	v1,v1,v8
   11546:	26238157          	vand.vv	v2,v2,v7
   1154a:	98b2                	add	a7,a7,a2
   1154c:	9e32                	add	t3,t3,a2
   1154e:	2a1100d7          	vor.vv	v1,v1,v2
   11552:	2610b157          	vand.vi	v2,v1,1
   11556:	a210b0d7          	vsrl.vi	v1,v1,1
   1155a:	9624a157          	vmul.vv	v2,v2,v9
   1155e:	2e1180d7          	vxor.vv	v1,v1,v3
   11562:	2e2080d7          	vxor.vv	v1,v2,v1
   11566:	0205f0a7          	vse64.v	v1,(a1)
   1156a:	95b2                	add	a1,a1,a2
   1156c:	fd5d                	bnez	a0,1152a <main+0x7aa>
   1156e:	71830693          	addi	a3,t1,1816
   11572:	cd817057          	vsetivli	zero,2,e64,m1,ta,ma
   11576:	00868613          	addi	a2,a3,8
   1157a:	02067087          	vle64.v	v1,(a2)
   1157e:	0206f107          	vle64.v	v2,(a3)
   11582:	8e868613          	addi	a2,a3,-1816
   11586:	02067187          	vle64.v	v3,(a2)
   1158a:	261300d7          	vand.vv	v1,v1,v6
   1158e:	26228157          	vand.vv	v2,v2,v5
   11592:	2a1100d7          	vor.vv	v1,v1,v2
   11596:	2610b157          	vand.vi	v2,v1,1
   1159a:	a210b0d7          	vsrl.vi	v1,v1,1
   1159e:	96222157          	vmul.vv	v2,v2,v4
   115a2:	2e1180d7          	vxor.vv	v1,v1,v3
   115a6:	2e1100d7          	vxor.vv	v1,v1,v2
   115aa:	0206f0a7          	vse64.v	v1,(a3)
   115ae:	06c1                	addi	a3,a3,16
   115b0:	fcf693e3          	bne	a3,a5,11576 <main+0x7f6>
   115b4:	6685                	lui	a3,0x1
   115b6:	0890                	addi	a2,sp,80
   115b8:	40068693          	addi	a3,a3,1024 # 1400 <_PROCEDURE_LINKAGE_TABLE_-0xf840>
   115bc:	96b2                	add	a3,a3,a2
   115be:	c78eb583          	ld	a1,-904(t4)
   115c2:	6294                	ld	a3,0(a3)
   115c4:	53910613          	addi	a2,sp,1337
   115c8:	7ff63503          	ld	a0,2047(a2)
   115cc:	02159613          	slli	a2,a1,0x21
   115d0:	9205                	srli	a2,a2,0x21
   115d2:	0056f6b3          	and	a3,a3,t0
   115d6:	8ed1                	or	a3,a3,a2
   115d8:	03f69813          	slli	a6,a3,0x3f
   115dc:	0016d613          	srli	a2,a3,0x1
   115e0:	43f85693          	srai	a3,a6,0x3f
   115e4:	8e29                	xor	a2,a2,a0
   115e6:	01f6f6b3          	and	a3,a3,t6
   115ea:	8eb1                	xor	a3,a3,a2
   115ec:	6605                	lui	a2,0x1
   115ee:	40060613          	addi	a2,a2,1024 # 1400 <_PROCEDURE_LINKAGE_TABLE_-0xf840>
   115f2:	0888                	addi	a0,sp,80
   115f4:	962a                	add	a2,a2,a0
   115f6:	e214                	sd	a3,0(a2)
   115f8:	4685                	li	a3,1
   115fa:	b3e9                	j	113c4 <main+0x644>
   115fc:	09ac                	addi	a1,sp,216
   115fe:	54110813          	addi	a6,sp,1345
   11602:	7ff80813          	addi	a6,a6,2047
   11606:	0e010393          	addi	t2,sp,224
   1160a:	88ae                	mv	a7,a1
   1160c:	0e300513          	li	a0,227
   11610:	82b6                	mv	t0,a3
   11612:	0d8576d7          	vsetvli	a3,a0,e64,m1,ta,ma
   11616:	0203f087          	vle64.v	v1,(t2)
   1161a:	0208f107          	vle64.v	v2,(a7)
   1161e:	02087187          	vle64.v	v3,(a6)
   11622:	00369613          	slli	a2,a3,0x3
   11626:	8d15                	sub	a0,a0,a3
   11628:	9832                	add	a6,a6,a2
   1162a:	261400d7          	vand.vv	v1,v1,v8
   1162e:	26238157          	vand.vv	v2,v2,v7
   11632:	98b2                	add	a7,a7,a2
   11634:	93b2                	add	t2,t2,a2
   11636:	2a1100d7          	vor.vv	v1,v1,v2
   1163a:	2610b157          	vand.vi	v2,v1,1
   1163e:	a210b0d7          	vsrl.vi	v1,v1,1
   11642:	9624a157          	vmul.vv	v2,v2,v9
   11646:	2e1180d7          	vxor.vv	v1,v1,v3
   1164a:	2e2080d7          	vxor.vv	v1,v2,v1
   1164e:	0205f0a7          	vse64.v	v1,(a1)
   11652:	95b2                	add	a1,a1,a2
   11654:	fd5d                	bnez	a0,11612 <main+0x892>
   11656:	8696                	mv	a3,t0
   11658:	71830613          	addi	a2,t1,1816
   1165c:	cd817057          	vsetivli	zero,2,e64,m1,ta,ma
   11660:	00860593          	addi	a1,a2,8
   11664:	0205f087          	vle64.v	v1,(a1)
   11668:	02067107          	vle64.v	v2,(a2)
   1166c:	8e860593          	addi	a1,a2,-1816
   11670:	0205f187          	vle64.v	v3,(a1)
   11674:	261300d7          	vand.vv	v1,v1,v6
   11678:	26228157          	vand.vv	v2,v2,v5
   1167c:	2a1100d7          	vor.vv	v1,v1,v2
   11680:	2610b157          	vand.vi	v2,v1,1
   11684:	a210b0d7          	vsrl.vi	v1,v1,1
   11688:	96222157          	vmul.vv	v2,v2,v4
   1168c:	2e1180d7          	vxor.vv	v1,v1,v3
   11690:	2e1100d7          	vxor.vv	v1,v1,v2
   11694:	020670a7          	vse64.v	v1,(a2)
   11698:	0641                	addi	a2,a2,16
   1169a:	fcc793e3          	bne	a5,a2,11660 <main+0x8e0>
   1169e:	6605                	lui	a2,0x1
   116a0:	088c                	addi	a1,sp,80
   116a2:	40060613          	addi	a2,a2,1024 # 1400 <_PROCEDURE_LINKAGE_TABLE_-0xf840>
   116a6:	962e                	add	a2,a2,a1
   116a8:	c78e3503          	ld	a0,-904(t3)
   116ac:	6210                	ld	a2,0(a2)
   116ae:	53910593          	addi	a1,sp,1337
   116b2:	7ff5b803          	ld	a6,2047(a1)
   116b6:	02151593          	slli	a1,a0,0x21
   116ba:	9185                	srli	a1,a1,0x21
   116bc:	01f67633          	and	a2,a2,t6
   116c0:	8e4d                	or	a2,a2,a1
   116c2:	03f61893          	slli	a7,a2,0x3f
   116c6:	00165593          	srli	a1,a2,0x1
   116ca:	43f8d613          	srai	a2,a7,0x3f
   116ce:	0105c5b3          	xor	a1,a1,a6
   116d2:	01e67633          	and	a2,a2,t5
   116d6:	8e2d                	xor	a2,a2,a1
   116d8:	6585                	lui	a1,0x1
   116da:	40058593          	addi	a1,a1,1024 # 1400 <_PROCEDURE_LINKAGE_TABLE_-0xf840>
   116de:	05010813          	addi	a6,sp,80
   116e2:	95c2                	add	a1,a1,a6
   116e4:	e190                	sd	a2,0(a1)
   116e6:	4585                	li	a1,1
   116e8:	b919                	j	112fe <main+0x57e>
   116ea:	85e6                	mv	a1,s9
   116ec:	8556                	mv	a0,s5
   116ee:	8426                	mv	s0,s1
   116f0:	84da                	mv	s1,s6
   116f2:	7b66                	ld	s6,120(sp)
   116f4:	3e0010ef          	jal	12ad4 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]>
   116f8:	415c87b3          	sub	a5,s9,s5
   116fc:	8785                	srai	a5,a5,0x1
   116fe:	9be1                	andi	a5,a5,-8
   11700:	97d6                	add	a5,a5,s5
   11702:	2380                	fld	fs0,0(a5)
   11704:	000a8763          	beqz	s5,11712 <main+0x992>
   11708:	415b85b3          	sub	a1,s7,s5
   1170c:	8556                	mv	a0,s5
   1170e:	d82ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   11712:	4a01                	li	s4,0
   11714:	000d0e63          	beqz	s10,11730 <main+0x9b0>
   11718:	884e                	mv	a6,s3
   1171a:	87ca                	mv	a5,s2
   1171c:	4705                	li	a4,1
   1171e:	4699                	li	a3,6
   11720:	866e                	mv	a2,s11
   11722:	85a2                	mv	a1,s0
   11724:	8526                	mv	a0,s1
   11726:	6b1000ef          	jal	125d6 <attention_bmm_rvv_f32>
   1172a:	2a05                	addiw	s4,s4,1
   1172c:	ff4d16e3          	bne	s10,s4,11718 <main+0x998>
   11730:	7a46                	ld	s4,112(sp)
   11732:	8552                	mv	a0,s4
   11734:	d4cff0ef          	jal	10c80 <operator new(unsigned long)@plt>
   11738:	67d5                	lui	a5,0x15
   1173a:	f8da                	sd	s6,112(sp)
   1173c:	0907b907          	fld	fs2,144(a5) # 15090 <__TMC_END__>
   11740:	8b26                	mv	s6,s1
   11742:	8caa                	mv	s9,a0
   11744:	9a2a                	add	s4,s4,a0
   11746:	8aaa                	mv	s5,a0
   11748:	46010b93          	addi	s7,sp,1120
   1174c:	4c01                	li	s8,0
   1174e:	84a2                	mv	s1,s0
   11750:	a801                	j	11760 <main+0x9e0>
   11752:	00fcb027          	fsd	fa5,0(s9)
   11756:	0ca1                	addi	s9,s9,8
   11758:	77c2                	ld	a5,48(sp)
   1175a:	2c05                	addiw	s8,s8,1
   1175c:	04fc5b63          	bge	s8,a5,117b2 <main+0xa32>
   11760:	d80ff0ef          	jal	10ce0 <std::chrono::_V2::steady_clock::now()@plt>
   11764:	842a                	mv	s0,a0
   11766:	884e                	mv	a6,s3
   11768:	87ca                	mv	a5,s2
   1176a:	866e                	mv	a2,s11
   1176c:	85a6                	mv	a1,s1
   1176e:	855a                	mv	a0,s6
   11770:	4705                	li	a4,1
   11772:	4699                	li	a3,6
   11774:	663000ef          	jal	125d6 <attention_bmm_rvv_f32>
   11778:	d68ff0ef          	jal	10ce0 <std::chrono::_V2::steady_clock::now()@plt>
   1177c:	408507b3          	sub	a5,a0,s0
   11780:	d227f7d3          	fcvt.d.l	fa5,a5
   11784:	1b27f7d3          	fdiv.d	fa5,fa5,fs2
   11788:	c2fbb027          	fsd	fa5,-992(s7) # 77e2c20 <__BSS_END__+0x77bda20>
   1178c:	fd9a13e3          	bne	s4,s9,11752 <main+0x9d2>
   11790:	c55bb023          	sd	s5,-960(s7)
   11794:	010c                	addi	a1,sp,128
   11796:	c54bb423          	sd	s4,-952(s7)
   1179a:	c54bb823          	sd	s4,-944(s7)
   1179e:	1108                	addi	a0,sp,160
   117a0:	416010ef          	jal	12bb6 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)>
   117a4:	c40bba83          	ld	s5,-960(s7)
   117a8:	c48bbc83          	ld	s9,-952(s7)
   117ac:	c50bba03          	ld	s4,-944(s7)
   117b0:	b765                	j	11758 <main+0x9d8>
   117b2:	67c6                	ld	a5,80(sp)
   117b4:	85e6                	mv	a1,s9
   117b6:	8556                	mv	a0,s5
   117b8:	00fd8bb3          	add	s7,s11,a5
   117bc:	8426                	mv	s0,s1
   117be:	84da                	mv	s1,s6
   117c0:	7b46                	ld	s6,112(sp)
   117c2:	312010ef          	jal	12ad4 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]>
   117c6:	415c87b3          	sub	a5,s9,s5
   117ca:	8785                	srai	a5,a5,0x1
   117cc:	9be1                	andi	a5,a5,-8
   117ce:	97d6                	add	a5,a5,s5
   117d0:	0007b907          	fld	fs2,0(a5)
   117d4:	000a8763          	beqz	s5,117e2 <main+0xa62>
   117d8:	415a05b3          	sub	a1,s4,s5
   117dc:	8556                	mv	a0,s5
   117de:	cb2ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   117e2:	1b2476d3          	fdiv.d	fa3,fs0,fs2
   117e6:	f2000753          	fmv.d.x	fa4,zero
   117ea:	000b2787          	flw	fa5,0(s6)
   117ee:	0b11                	addi	s6,s6,4
   117f0:	420787d3          	fcvt.d.s	fa5,fa5
   117f4:	02f77753          	fadd.d	fa4,fa4,fa5
   117f8:	ff6b99e3          	bne	s7,s6,117ea <main+0xa6a>
   117fc:	67a6                	ld	a5,72(sp)
   117fe:	420484d3          	fcvt.d.s	fs1,fs1
   11802:	75ea                	ld	a1,184(sp)
   11804:	c7b1                	beqz	a5,11850 <main+0xad0>
   11806:	e20908d3          	fmv.x.d	a7,fs2
   1180a:	e2040853          	fmv.x.d	a6,fs0
   1180e:	77c2                	ld	a5,48(sp)
   11810:	7662                	ld	a2,56(sp)
   11812:	654d                	lui	a0,0x13
   11814:	a83a                	fsd	fa4,16(sp)
   11816:	a426                	fsd	fs1,8(sp)
   11818:	a036                	fsd	fa3,0(sp)
   1181a:	874e                	mv	a4,s3
   1181c:	86ca                	mv	a3,s2
   1181e:	eb050513          	addi	a0,a0,-336 # 12eb0 <_IO_stdin_used+0x250>
   11822:	d2eff0ef          	jal	10d50 <printf@plt>
   11826:	4901                	li	s2,0
   11828:	69c6                	ld	s3,80(sp)
   1182a:	856e                	mv	a0,s11
   1182c:	85ce                	mv	a1,s3
   1182e:	c62ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   11832:	6506                	ld	a0,64(sp)
   11834:	85ce                	mv	a1,s3
   11836:	c5aff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   1183a:	c409                	beqz	s0,11844 <main+0xac4>
   1183c:	75a6                	ld	a1,104(sp)
   1183e:	8522                	mv	a0,s0
   11840:	c50ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   11844:	65e6                	ld	a1,88(sp)
   11846:	8526                	mv	a0,s1
   11848:	c48ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   1184c:	f70ff06f          	j	10fbc <main+0x23c>
   11850:	77c2                	ld	a5,48(sp)
   11852:	7662                	ld	a2,56(sp)
   11854:	654d                	lui	a0,0x13
   11856:	e03e                	sd	a5,0(sp)
   11858:	b43a                	fsd	fa4,40(sp)
   1185a:	b026                	fsd	fs1,32(sp)
   1185c:	ac36                	fsd	fa3,24(sp)
   1185e:	a84a                	fsd	fs2,16(sp)
   11860:	a422                	fsd	fs0,8(sp)
   11862:	88ea                	mv	a7,s10
   11864:	884e                	mv	a6,s3
   11866:	87ca                	mv	a5,s2
   11868:	ee050513          	addi	a0,a0,-288 # 12ee0 <_IO_stdin_used+0x280>
   1186c:	4705                	li	a4,1
   1186e:	4699                	li	a3,6
   11870:	ce0ff0ef          	jal	10d50 <printf@plt>
   11874:	bf4d                	j	11826 <main+0xaa6>
   11876:	67d5                	lui	a5,0x15
   11878:	0987a407          	flw	fs0,152(a5) # 15098 <__TMC_END__+0x8>
   1187c:	57fd                	li	a5,-1
   1187e:	fc3e                	sd	a5,56(sp)
   11880:	06400793          	li	a5,100
   11884:	4d29                	li	s10,10
   11886:	e482                	sd	zero,72(sp)
   11888:	f83e                	sd	a5,48(sp)
   1188a:	b06d                	j	11134 <main+0x3b4>
   1188c:	420407d3          	fcvt.d.s	fa5,fs0
   11890:	6755                	lui	a4,0x15
   11892:	0c073503          	ld	a0,192(a4) # 150c0 <stderr@GLIBC_2.27>
   11896:	e20787d3          	fmv.x.d	a5,fa5
   1189a:	420487d3          	fcvt.d.s	fa5,fs1
   1189e:	766a                	ld	a2,184(sp)
   118a0:	76e2                	ld	a3,56(sp)
   118a2:	e2078753          	fmv.x.d	a4,fa5
   118a6:	65cd                	lui	a1,0x13
   118a8:	e7058593          	addi	a1,a1,-400 # 12e70 <_IO_stdin_used+0x210>
   118ac:	c84ff0ef          	jal	10d30 <fprintf@plt>
   118b0:	490d                	li	s2,3
   118b2:	bf9d                	j	11828 <main+0xaa8>
   118b4:	892a                	mv	s2,a0
   118b6:	c419                	beqz	s0,118c4 <main+0xb44>
   118b8:	7786                	ld	a5,96(sp)
   118ba:	8522                	mv	a0,s0
   118bc:	408785b3          	sub	a1,a5,s0
   118c0:	bd0ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   118c4:	844a                	mv	s0,s2
   118c6:	65e6                	ld	a1,88(sp)
   118c8:	8526                	mv	a0,s1
   118ca:	bc6ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   118ce:	1928                	addi	a0,sp,184
   118d0:	bf0ff0ef          	jal	10cc0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@plt>
   118d4:	8522                	mv	a0,s0
   118d6:	c6aff0ef          	jal	10d40 <_Unwind_Resume@plt>
   118da:	654d                	lui	a0,0x13
   118dc:	e3850513          	addi	a0,a0,-456 # 12e38 <_IO_stdin_used+0x1d8>
   118e0:	b80ff0ef          	jal	10c60 <std::__throw_length_error(char const*)@plt>
   118e4:	842a                	mv	s0,a0
   118e6:	b7e5                	j	118ce <main+0xb4e>
   118e8:	7a8a                	ld	s5,160(sp)
   118ea:	8426                	mv	s0,s1
   118ec:	7a4a                	ld	s4,176(sp)
   118ee:	84da                	mv	s1,s6
   118f0:	892a                	mv	s2,a0
   118f2:	000a9c63          	bnez	s5,1190a <main+0xb8a>
   118f6:	65c6                	ld	a1,80(sp)
   118f8:	856e                	mv	a0,s11
   118fa:	b96ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   118fe:	65c6                	ld	a1,80(sp)
   11900:	6506                	ld	a0,64(sp)
   11902:	b8eff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   11906:	f84d                	bnez	s0,118b8 <main+0xb38>
   11908:	bf75                	j	118c4 <main+0xb44>
   1190a:	415a05b3          	sub	a1,s4,s5
   1190e:	8556                	mv	a0,s5
   11910:	b80ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   11914:	b7cd                	j	118f6 <main+0xb76>
   11916:	8426                	mv	s0,s1
   11918:	892a                	mv	s2,a0
   1191a:	84da                	mv	s1,s6
   1191c:	fe0a97e3          	bnez	s5,1190a <main+0xb8a>
   11920:	bfd9                	j	118f6 <main+0xb76>
   11922:	892a                	mv	s2,a0
   11924:	bfc9                	j	118f6 <main+0xb76>
   11926:	842a                	mv	s0,a0
   11928:	bf79                	j	118c6 <main+0xb46>
   1192a:	6aaa                	ld	s5,136(sp)
   1192c:	8426                	mv	s0,s1
   1192e:	6bea                	ld	s7,152(sp)
   11930:	84da                	mv	s1,s6
   11932:	892a                	mv	s2,a0
   11934:	fc0a81e3          	beqz	s5,118f6 <main+0xb76>
   11938:	415b85b3          	sub	a1,s7,s5
   1193c:	8556                	mv	a0,s5
   1193e:	b52ff0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   11942:	bf55                	j	118f6 <main+0xb76>
   11944:	8426                	mv	s0,s1
   11946:	892a                	mv	s2,a0
   11948:	84da                	mv	s1,s6
   1194a:	fe0a97e3          	bnez	s5,11938 <main+0xbb8>
   1194e:	b765                	j	118f6 <main+0xb76>
   11950:	892a                	mv	s2,a0
   11952:	b755                	j	118f6 <main+0xb76>
   11954:	892a                	mv	s2,a0
   11956:	b765                	j	118fe <main+0xb7e>
   11958:	892a                	mv	s2,a0
   1195a:	bf71                	j	118f6 <main+0xb76>

000000000001195c <_start>:
   1195c:	026000ef          	jal	11982 <load_gp>
   11960:	87aa                	mv	a5,a0
   11962:	00000517          	auipc	a0,0x0
   11966:	01c50513          	addi	a0,a0,28 # 1197e <__wrap_main>
   1196a:	6582                	ld	a1,0(sp)
   1196c:	0030                	addi	a2,sp,8
   1196e:	ff017113          	andi	sp,sp,-16
   11972:	4681                	li	a3,0
   11974:	4701                	li	a4,0
   11976:	880a                	mv	a6,sp
   11978:	af8ff0ef          	jal	10c70 <__libc_start_main@plt>
   1197c:	9002                	ebreak

000000000001197e <__wrap_main>:
   1197e:	c02ff06f          	j	10d80 <main>

0000000000011982 <load_gp>:
   11982:	00004197          	auipc	gp,0x4
   11986:	f0e18193          	addi	gp,gp,-242 # 15890 <__global_pointer$>
   1198a:	8082                	ret
   1198c:	0001                	nop

000000000001198e <_dl_relocate_static_pie>:
   1198e:	8082                	ret

0000000000011990 <deregister_tm_clones>:
   11990:	6555                	lui	a0,0x15
   11992:	67d5                	lui	a5,0x15
   11994:	09050513          	addi	a0,a0,144 # 15090 <__TMC_END__>
   11998:	09078793          	addi	a5,a5,144 # 15090 <__TMC_END__>
   1199c:	00a78663          	beq	a5,a0,119a8 <deregister_tm_clones+0x18>
   119a0:	00000793          	li	a5,0
   119a4:	c391                	beqz	a5,119a8 <deregister_tm_clones+0x18>
   119a6:	8782                	jr	a5
   119a8:	8082                	ret

00000000000119aa <register_tm_clones>:
   119aa:	6555                	lui	a0,0x15
   119ac:	67d5                	lui	a5,0x15
   119ae:	09050513          	addi	a0,a0,144 # 15090 <__TMC_END__>
   119b2:	09078593          	addi	a1,a5,144 # 15090 <__TMC_END__>
   119b6:	8d89                	sub	a1,a1,a0
   119b8:	4035d793          	srai	a5,a1,0x3
   119bc:	91fd                	srli	a1,a1,0x3f
   119be:	95be                	add	a1,a1,a5
   119c0:	8585                	srai	a1,a1,0x1
   119c2:	c589                	beqz	a1,119cc <register_tm_clones+0x22>
   119c4:	00000793          	li	a5,0
   119c8:	c391                	beqz	a5,119cc <register_tm_clones+0x22>
   119ca:	8782                	jr	a5
   119cc:	8082                	ret

00000000000119ce <__do_global_dtors_aux>:
   119ce:	9501c703          	lbu	a4,-1712(gp) # 151e0 <completed.0>
   119d2:	eb19                	bnez	a4,119e8 <__do_global_dtors_aux+0x1a>
   119d4:	1141                	addi	sp,sp,-16
   119d6:	e406                	sd	ra,8(sp)
   119d8:	fb9ff0ef          	jal	11990 <deregister_tm_clones>
   119dc:	60a2                	ld	ra,8(sp)
   119de:	4705                	li	a4,1
   119e0:	94e18823          	sb	a4,-1712(gp) # 151e0 <completed.0>
   119e4:	0141                	addi	sp,sp,16
   119e6:	8082                	ret
   119e8:	8082                	ret

00000000000119ea <frame_dummy>:
   119ea:	b7c1                	j	119aa <register_tm_clones>

00000000000119ec <attention_bmm_rvv_baseline_f32>:
   119ec:	2cd05c63          	blez	a3,11cc4 <attention_bmm_rvv_baseline_f32+0x2d8>
   119f0:	2d005a63          	blez	a6,11cc4 <attention_bmm_rvv_baseline_f32+0x2d8>
   119f4:	712d                	addi	sp,sp,-288
   119f6:	83be                	mv	t2,a5
   119f8:	fff8079b          	addiw	a5,a6,-1
   119fc:	fc2a                	sd	a0,56(sp)
   119fe:	0077d79b          	srliw	a5,a5,0x7
   11a02:	fff3851b          	addiw	a0,t2,-1
   11a06:	2785                	addiw	a5,a5,1
   11a08:	f8057513          	andi	a0,a0,-128
   11a0c:	00281f93          	slli	t6,a6,0x2
   11a10:	f1da                	sd	s6,224(sp)
   11a12:	00779b13          	slli	s6,a5,0x7
   11a16:	0805079b          	addiw	a5,a0,128
   11a1a:	e626                	sd	s1,264(sp)
   11a1c:	f9d2                	sd	s4,240(sp)
   11a1e:	e5e6                	sd	s9,200(sp)
   11a20:	8a42                	mv	s4,a6
   11a22:	84b2                	mv	s1,a2
   11a24:	f83e                	sd	a5,48(sp)
   11a26:	03038633          	mul	a2,t2,a6
   11a2a:	00981793          	slli	a5,a6,0x9
   11a2e:	00681313          	slli	t1,a6,0x6
   11a32:	ea22                	sd	s0,272(sp)
   11a34:	fdce                	sd	s3,248(sp)
   11a36:	edde                	sd	s7,216(sp)
   11a38:	e1ea                	sd	s10,192(sp)
   11a3a:	03f70cb3          	mul	s9,a4,t6
   11a3e:	fd6e                	sd	s11,184(sp)
   11a40:	ee06                	sd	ra,280(sp)
   11a42:	e24a                	sd	s2,256(sp)
   11a44:	8436                	mv	s0,a3
   11a46:	00639293          	slli	t0,t2,0x6
   11a4a:	f03e                	sd	a5,32(sp)
   11a4c:	02770833          	mul	a6,a4,t2
   11a50:	00239993          	slli	s3,t2,0x2
   11a54:	4d01                	li	s10,0
   11a56:	4501                	li	a0,0
   11a58:	4d81                	li	s11,0
   11a5a:	8bfe                	mv	s7,t6
   11a5c:	08000793          	li	a5,128
   11a60:	000a091b          	sext.w	s2,s4
   11a64:	0147d463          	bge	a5,s4,11a6c <attention_bmm_rvv_baseline_f32+0x80>
   11a68:	0007891b          	sext.w	s2,a5
   11a6c:	1ee05463          	blez	a4,11c54 <attention_bmm_rvv_baseline_f32+0x268>
   11a70:	f5d6                	sd	s5,232(sp)
   11a72:	6ad5                	lui	s5,0x15
   11a74:	e9e2                	sd	s8,208(sp)
   11a76:	e4e6                	sd	s9,72(sp)
   11a78:	87da                	mv	a5,s6
   11a7a:	86ae                	mv	a3,a1
   11a7c:	200a8a93          	addi	s5,s5,512 # 15200 <do_block_matmul(float const*, float const*, float*, int, int, int)::Bpack>
   11a80:	4c01                	li	s8,0
   11a82:	e0ea                	sd	s10,64(sp)
   11a84:	8f6e                	mv	t5,s11
   11a86:	8cea                	mv	s9,s10
   11a88:	e8b2                	sd	a2,80(sp)
   11a8a:	88a2                	mv	a7,s0
   11a8c:	fff7059b          	addiw	a1,a4,-1
   11a90:	8b1e                	mv	s6,t2
   11a92:	002c9613          	slli	a2,s9,0x2
   11a96:	9636                	add	a2,a2,a3
   11a98:	fc05fe93          	andi	t4,a1,-64
   11a9c:	ec32                	sd	a2,24(sp)
   11a9e:	862a                	mv	a2,a0
   11aa0:	040e841b          	addiw	s0,t4,64
   11aa4:	f0be                	sd	a5,96(sp)
   11aa6:	87b2                	mv	a5,a2
   11aa8:	f422                	sd	s0,40(sp)
   11aaa:	ecaa                	sd	a0,88(sp)
   11aac:	8ec2                	mv	t4,a6
   11aae:	8666                	mv	a2,s9
   11ab0:	882e                	mv	a6,a1
   11ab2:	00291413          	slli	s0,s2,0x2
   11ab6:	85b6                	mv	a1,a3
   11ab8:	8de2                	mv	s11,s8
   11aba:	4d01                	li	s10,0
   11abc:	857a                	mv	a0,t5
   11abe:	86e2                	mv	a3,s8
   11ac0:	8cbe                	mv	s9,a5
   11ac2:	03fd079b          	addiw	a5,s10,63 # 77e303f <__BSS_END__+0x77bde3f>
   11ac6:	04000c13          	li	s8,64
   11aca:	00e7c463          	blt	a5,a4,11ad2 <attention_bmm_rvv_baseline_f32+0xe6>
   11ace:	41a70c3b          	subw	s8,a4,s10
   11ad2:	002d9793          	slli	a5,s11,0x2
   11ad6:	97a6                	add	a5,a5,s1
   11ad8:	e466                	sd	s9,8(sp)
   11ada:	e86e                	sd	s11,16(sp)
   11adc:	8cca                	mv	s9,s2
   11ade:	f4ce                	sd	s3,104(sp)
   11ae0:	fcda                	sd	s6,120(sp)
   11ae2:	e152                	sd	s4,128(sp)
   11ae4:	8b26                	mv	s6,s1
   11ae6:	8976                	mv	s2,t4
   11ae8:	84a2                	mv	s1,s0
   11aea:	8db2                	mv	s11,a2
   11aec:	89b6                	mv	s3,a3
   11aee:	f8ae                	sd	a1,112(sp)
   11af0:	4401                	li	s0,0
   11af2:	8a2a                	mv	s4,a0
   11af4:	853e                	mv	a0,a5
   11af6:	8626                	mv	a2,s1
   11af8:	4581                	li	a1,0
   11afa:	f53a                	sd	a4,168(sp)
   11afc:	f146                	sd	a7,160(sp)
   11afe:	ed42                	sd	a6,152(sp)
   11b00:	e91a                	sd	t1,144(sp)
   11b02:	e516                	sd	t0,136(sp)
   11b04:	2405                	addiw	s0,s0,1
   11b06:	9eaff0ef          	jal	10cf0 <memset@plt>
   11b0a:	62aa                	ld	t0,136(sp)
   11b0c:	634a                	ld	t1,144(sp)
   11b0e:	686a                	ld	a6,152(sp)
   11b10:	788a                	ld	a7,160(sp)
   11b12:	772a                	ld	a4,168(sp)
   11b14:	017507b3          	add	a5,a0,s7
   11b18:	fd841ee3          	bne	s0,s8,11af4 <attention_bmm_rvv_baseline_f32+0x108>
   11b1c:	8426                	mv	s0,s1
   11b1e:	84da                	mv	s1,s6
   11b20:	7b66                	ld	s6,120(sp)
   11b22:	8eca                	mv	t4,s2
   11b24:	86ce                	mv	a3,s3
   11b26:	8552                	mv	a0,s4
   11b28:	8966                	mv	s2,s9
   11b2a:	866e                	mv	a2,s11
   11b2c:	6ca2                	ld	s9,8(sp)
   11b2e:	6dc2                	ld	s11,16(sp)
   11b30:	79a6                	ld	s3,104(sp)
   11b32:	75c6                	ld	a1,112(sp)
   11b34:	6a0a                	ld	s4,128(sp)
   11b36:	0f605363          	blez	s6,11c1c <attention_bmm_rvv_baseline_f32+0x230>
   11b3a:	63e2                	ld	t2,24(sp)
   11b3c:	f8b6                	sd	a3,112(sp)
   11b3e:	e16a                	sd	s10,128(sp)
   11b40:	8fe6                	mv	t6,s9
   11b42:	4f01                	li	t5,0
   11b44:	e862                	sd	s8,16(sp)
   11b46:	f4f6                	sd	t4,104(sp)
   11b48:	fcaa                	sd	a0,120(sp)
   11b4a:	86e6                	mv	a3,s9
   11b4c:	8d16                	mv	s10,t0
   11b4e:	07ff079b          	addiw	a5,t5,127
   11b52:	08000c93          	li	s9,128
   11b56:	0167c463          	blt	a5,s6,11b5e <attention_bmm_rvv_baseline_f32+0x172>
   11b5a:	41eb0cbb          	subw	s9,s6,t5
   11b5e:	8e9e                	mv	t4,t2
   11b60:	8e56                	mv	t3,s5
   11b62:	4281                	li	t0,0
   11b64:	e426                	sd	s1,8(sp)
   11b66:	84f2                	mv	s1,t3
   11b68:	8c76                	mv	s8,t4
   11b6a:	8522                	mv	a0,s0
   11b6c:	0c0577d7          	vsetvli	a5,a0,e8,m1,ta,ma
   11b70:	020c0087          	vle8.v	v1,(s8)
   11b74:	8d1d                	sub	a0,a0,a5
   11b76:	9c3e                	add	s8,s8,a5
   11b78:	020480a7          	vse8.v	v1,(s1)
   11b7c:	94be                	add	s1,s1,a5
   11b7e:	f57d                	bnez	a0,11b6c <attention_bmm_rvv_baseline_f32+0x180>
   11b80:	2285                	addiw	t0,t0,1 # ffffffff80000001 <__BSS_END__+0xffffffff7ffdae01>
   11b82:	9e22                	add	t3,t3,s0
   11b84:	9ede                	add	t4,t4,s7
   11b86:	fe5c90e3          	bne	s9,t0,11b66 <attention_bmm_rvv_baseline_f32+0x17a>
   11b8a:	7e62                	ld	t3,56(sp)
   11b8c:	01fc8533          	add	a0,s9,t6
   11b90:	64a2                	ld	s1,8(sp)
   11b92:	002f9793          	slli	a5,t6,0x2
   11b96:	050a                	slli	a0,a0,0x2
   11b98:	00fe02b3          	add	t0,t3,a5
   11b9c:	9572                	add	a0,a0,t3
   11b9e:	8cee                	mv	s9,s11
   11ba0:	8e32                	mv	t3,a2
   11ba2:	4781                	li	a5,0
   11ba4:	e57a                	sd	t5,136(sp)
   11ba6:	865e                	mv	a2,s7
   11ba8:	4b81                	li	s7,0
   11baa:	e43e                	sd	a5,8(sp)
   11bac:	019b8c33          	add	s8,s7,s9
   11bb0:	0c0a                	slli	s8,s8,0x2
   11bb2:	41790f3b          	subw	t5,s2,s7
   11bb6:	9c26                	add	s8,s8,s1
   11bb8:	0d0f7f57          	vsetvli	t5,t5,e32,m1,ta,ma
   11bbc:	020c6087          	vle32.v	v1,(s8)
   11bc0:	002b9e93          	slli	t4,s7,0x2
   11bc4:	9ed6                	add	t4,t4,s5
   11bc6:	8796                	mv	a5,t0
   11bc8:	020ee107          	vle32.v	v2,(t4)
   11bcc:	0007a787          	flw	fa5,0(a5)
   11bd0:	0791                	addi	a5,a5,4
   11bd2:	9ea2                	add	t4,t4,s0
   11bd4:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   11bd8:	fef518e3          	bne	a0,a5,11bc8 <attention_bmm_rvv_baseline_f32+0x1dc>
   11bdc:	020c60a7          	vse32.v	v1,(s8)
   11be0:	017f0bbb          	addw	s7,t5,s7
   11be4:	fd2bc4e3          	blt	s7,s2,11bac <attention_bmm_rvv_baseline_f32+0x1c0>
   11be8:	67a2                	ld	a5,8(sp)
   11bea:	6ec2                	ld	t4,16(sp)
   11bec:	92ce                	add	t0,t0,s3
   11bee:	2785                	addiw	a5,a5,1
   11bf0:	954e                	add	a0,a0,s3
   11bf2:	9cd2                	add	s9,s9,s4
   11bf4:	fafe9ae3          	bne	t4,a5,11ba8 <attention_bmm_rvv_baseline_f32+0x1bc>
   11bf8:	7782                	ld	a5,32(sp)
   11bfa:	6f2a                	ld	t5,136(sp)
   11bfc:	8bb2                	mv	s7,a2
   11bfe:	93be                	add	t2,t2,a5
   11c00:	77c2                	ld	a5,48(sp)
   11c02:	080f0f1b          	addiw	t5,t5,128
   11c06:	8672                	mv	a2,t3
   11c08:	080f8f93          	addi	t6,t6,128
   11c0c:	f4ff11e3          	bne	t5,a5,11b4e <attention_bmm_rvv_baseline_f32+0x162>
   11c10:	8cb6                	mv	s9,a3
   11c12:	82ea                	mv	t0,s10
   11c14:	7ea6                	ld	t4,104(sp)
   11c16:	7566                	ld	a0,120(sp)
   11c18:	76c6                	ld	a3,112(sp)
   11c1a:	6d0a                	ld	s10,128(sp)
   11c1c:	77a2                	ld	a5,40(sp)
   11c1e:	040d0d1b          	addiw	s10,s10,64
   11c22:	9d9a                	add	s11,s11,t1
   11c24:	9c96                	add	s9,s9,t0
   11c26:	e8fd1ee3          	bne	s10,a5,11ac2 <attention_bmm_rvv_baseline_f32+0xd6>
   11c2a:	7786                	ld	a5,96(sp)
   11c2c:	08068c13          	addi	s8,a3,128
   11c30:	8f2a                	mv	t5,a0
   11c32:	86ae                	mv	a3,a1
   11c34:	6566                	ld	a0,88(sp)
   11c36:	85c2                	mv	a1,a6
   11c38:	8876                	mv	a6,t4
   11c3a:	07878463          	beq	a5,s8,11ca2 <attention_bmm_rvv_baseline_f32+0x2b6>
   11c3e:	08060c93          	addi	s9,a2,128
   11c42:	07fc061b          	addiw	a2,s8,127
   11c46:	08000913          	li	s2,128
   11c4a:	e54644e3          	blt	a2,s4,11a92 <attention_bmm_rvv_baseline_f32+0xa6>
   11c4e:	418a093b          	subw	s2,s4,s8
   11c52:	b581                	j	11a92 <attention_bmm_rvv_baseline_f32+0xa6>
   11c54:	4681                	li	a3,0
   11c56:	08068793          	addi	a5,a3,128
   11c5a:	07f7889b          	addiw	a7,a5,127
   11c5e:	00fb0f63          	beq	s6,a5,11c7c <attention_bmm_rvv_baseline_f32+0x290>
   11c62:	0148d663          	bge	a7,s4,11c6e <attention_bmm_rvv_baseline_f32+0x282>
   11c66:	10068793          	addi	a5,a3,256
   11c6a:	00fb0963          	beq	s6,a5,11c7c <attention_bmm_rvv_baseline_f32+0x290>
   11c6e:	86be                	mv	a3,a5
   11c70:	08068793          	addi	a5,a3,128
   11c74:	07f7889b          	addiw	a7,a5,127
   11c78:	fefb15e3          	bne	s6,a5,11c62 <attention_bmm_rvv_baseline_f32+0x276>
   11c7c:	2d85                	addiw	s11,s11,1
   11c7e:	94e6                	add	s1,s1,s9
   11c80:	9542                	add	a0,a0,a6
   11c82:	9d32                	add	s10,s10,a2
   11c84:	ddb41ce3          	bne	s0,s11,11a5c <attention_bmm_rvv_baseline_f32+0x70>
   11c88:	60f2                	ld	ra,280(sp)
   11c8a:	6452                	ld	s0,272(sp)
   11c8c:	64b2                	ld	s1,264(sp)
   11c8e:	6912                	ld	s2,256(sp)
   11c90:	79ee                	ld	s3,248(sp)
   11c92:	7a4e                	ld	s4,240(sp)
   11c94:	7b0e                	ld	s6,224(sp)
   11c96:	6bee                	ld	s7,216(sp)
   11c98:	6cae                	ld	s9,200(sp)
   11c9a:	6d0e                	ld	s10,192(sp)
   11c9c:	7dea                	ld	s11,184(sp)
   11c9e:	6115                	addi	sp,sp,288
   11ca0:	8082                	ret
   11ca2:	6d06                	ld	s10,64(sp)
   11ca4:	6ca6                	ld	s9,72(sp)
   11ca6:	6646                	ld	a2,80(sp)
   11ca8:	8dfa                	mv	s11,t5
   11caa:	8446                	mv	s0,a7
   11cac:	2d85                	addiw	s11,s11,1
   11cae:	83da                	mv	t2,s6
   11cb0:	7aae                	ld	s5,232(sp)
   11cb2:	6c4e                	ld	s8,208(sp)
   11cb4:	85b6                	mv	a1,a3
   11cb6:	8b3e                	mv	s6,a5
   11cb8:	94e6                	add	s1,s1,s9
   11cba:	9542                	add	a0,a0,a6
   11cbc:	9d32                	add	s10,s10,a2
   11cbe:	d9b41fe3          	bne	s0,s11,11a5c <attention_bmm_rvv_baseline_f32+0x70>
   11cc2:	b7d9                	j	11c88 <attention_bmm_rvv_baseline_f32+0x29c>
   11cc4:	8082                	ret

0000000000011cc6 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)>:
   11cc6:	30d05d63          	blez	a3,11fe0 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x31a>
   11cca:	0c107fd7          	vsetvli	t6,zero,e8,m2,ta,ma
   11cce:	711d                	addi	sp,sp,-96
   11cd0:	0c1ff7d7          	vsetvli	a5,t6,e8,m2,ta,ma
   11cd4:	e4ca                	sd	s2,72(sp)
   11cd6:	0c007957          	vsetvli	s2,zero,e8,m1,ta,ma
   11cda:	e8a6                	sd	s1,80(sp)
   11cdc:	0c7074d7          	vsetvli	s1,zero,e8,mf2,ta,ma
   11ce0:	06a2                	slli	a3,a3,0x8
   11ce2:	001f981b          	slliw	a6,t6,0x1
   11ce6:	0007889b          	sext.w	a7,a5
   11cea:	0c6072d7          	vsetvli	t0,zero,e8,mf4,ta,ma
   11cee:	00d503b3          	add	t2,a0,a3
   11cf2:	eca2                	sd	s0,88(sp)
   11cf4:	e0ce                	sd	s3,64(sp)
   11cf6:	8e2a                	mv	t3,a0
   11cf8:	41f709bb          	subw	s3,a4,t6
   11cfc:	fc52                	sd	s4,56(sp)
   11cfe:	f856                	sd	s5,48(sp)
   11d00:	f45a                	sd	s6,40(sp)
   11d02:	f05e                	sd	s7,32(sp)
   11d04:	ec62                	sd	s8,24(sp)
   11d06:	e866                	sd	s9,16(sp)
   11d08:	e46a                	sd	s10,8(sp)
   11d0a:	e06e                	sd	s11,0(sp)
   11d0c:	8f32                	mv	t5,a2
   11d0e:	8eae                	mv	t4,a1
   11d10:	088a                	slli	a7,a7,0x2
   11d12:	00281313          	slli	t1,a6,0x2
   11d16:	10050513          	addi	a0,a0,256
   11d1a:	00271693          	slli	a3,a4,0x2
   11d1e:	00871413          	slli	s0,a4,0x8
   11d22:	0d307fd7          	vsetvli	t6,zero,e32,m8,ta,ma
   11d26:	2b074a63          	blt	a4,a6,11fda <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x314>
   11d2a:	5e003057          	vmv.v.i	v0,0
   11d2e:	8d76                	mv	s10,t4
   11d30:	8cfa                	mv	s9,t5
   11d32:	4b01                	li	s6,0
   11d34:	9e03b857          	vmv8r.v	v16,v0
   11d38:	9e03b457          	vmv8r.v	v8,v0
   11d3c:	01a88a33          	add	s4,a7,s10
   11d40:	85ea                	mv	a1,s10
   11d42:	8672                	mv	a2,t3
   11d44:	0d307fd7          	vsetvli	t6,zero,e32,m8,ta,ma
   11d48:	0205ec07          	vle32.v	v24,(a1)
   11d4c:	00062607          	flw	fa2,0(a2)
   11d50:	95b6                	add	a1,a1,a3
   11d52:	00462687          	flw	fa3,4(a2)
   11d56:	00b68ab3          	add	s5,a3,a1
   11d5a:	00862707          	flw	fa4,8(a2)
   11d5e:	b3865857          	vfmacc.vf	v16,fa2,v24
   11d62:	0205ec07          	vle32.v	v24,(a1)
   11d66:	01568db3          	add	s11,a3,s5
   11d6a:	00c62787          	flw	fa5,12(a2)
   11d6e:	01468c33          	add	s8,a3,s4
   11d72:	01868bb3          	add	s7,a3,s8
   11d76:	0641                	addi	a2,a2,16
   11d78:	b386d857          	vfmacc.vf	v16,fa3,v24
   11d7c:	020aec07          	vle32.v	v24,(s5)
   11d80:	01768ab3          	add	s5,a3,s7
   11d84:	01b685b3          	add	a1,a3,s11
   11d88:	b3875857          	vfmacc.vf	v16,fa4,v24
   11d8c:	020dec07          	vle32.v	v24,(s11)
   11d90:	b387d857          	vfmacc.vf	v16,fa5,v24
   11d94:	020a6c07          	vle32.v	v24,(s4)
   11d98:	01568a33          	add	s4,a3,s5
   11d9c:	b3865457          	vfmacc.vf	v8,fa2,v24
   11da0:	020c6c07          	vle32.v	v24,(s8)
   11da4:	b386d457          	vfmacc.vf	v8,fa3,v24
   11da8:	020bec07          	vle32.v	v24,(s7)
   11dac:	b3875457          	vfmacc.vf	v8,fa4,v24
   11db0:	020aec07          	vle32.v	v24,(s5)
   11db4:	b387d457          	vfmacc.vf	v8,fa5,v24
   11db8:	f8c518e3          	bne	a0,a2,11d48 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x82>
   11dbc:	020ce827          	vse32.v	v16,(s9)
   11dc0:	019885b3          	add	a1,a7,s9
   11dc4:	01680b3b          	addw	s6,a6,s6
   11dc8:	4167063b          	subw	a2,a4,s6
   11dcc:	9d1a                	add	s10,s10,t1
   11dce:	9c9a                	add	s9,s9,t1
   11dd0:	0205e427          	vse32.v	v8,(a1)
   11dd4:	f70650e3          	bge	a2,a6,11d34 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x6e>
   11dd8:	02eb4863          	blt	s6,a4,11e08 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x142>
   11ddc:	100e0e13          	addi	t3,t3,256
   11de0:	9f36                	add	t5,t5,a3
   11de2:	10050513          	addi	a0,a0,256
   11de6:	9ea2                	add	t4,t4,s0
   11de8:	f3c39fe3          	bne	t2,t3,11d26 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x60>
   11dec:	6466                	ld	s0,88(sp)
   11dee:	64c6                	ld	s1,80(sp)
   11df0:	6926                	ld	s2,72(sp)
   11df2:	6986                	ld	s3,64(sp)
   11df4:	7a62                	ld	s4,56(sp)
   11df6:	7ac2                	ld	s5,48(sp)
   11df8:	7b22                	ld	s6,40(sp)
   11dfa:	7b82                	ld	s7,32(sp)
   11dfc:	6c62                	ld	s8,24(sp)
   11dfe:	6cc2                	ld	s9,16(sp)
   11e00:	6d22                	ld	s10,8(sp)
   11e02:	6d82                	ld	s11,0(sp)
   11e04:	6125                	addi	sp,sp,96
   11e06:	8082                	ret
   11e08:	07f64f63          	blt	a2,t6,11e86 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1c0>
   11e0c:	5e003057          	vmv.v.i	v0,0
   11e10:	8ada                	mv	s5,s6
   11e12:	f0050593          	addi	a1,a0,-256
   11e16:	002a9b13          	slli	s6,s5,0x2
   11e1a:	9e03b457          	vmv8r.v	v8,v0
   11e1e:	016e8633          	add	a2,t4,s6
   11e22:	8a2e                	mv	s4,a1
   11e24:	0d307fd7          	vsetvli	t6,zero,e32,m8,ta,ma
   11e28:	02066c07          	vle32.v	v24,(a2)
   11e2c:	000a2787          	flw	fa5,0(s4)
   11e30:	9636                	add	a2,a2,a3
   11e32:	02066807          	vle32.v	v16,(a2)
   11e36:	004a2687          	flw	fa3,4(s4)
   11e3a:	9636                	add	a2,a2,a3
   11e3c:	b387d457          	vfmacc.vf	v8,fa5,v24
   11e40:	02066c07          	vle32.v	v24,(a2)
   11e44:	008a2707          	flw	fa4,8(s4)
   11e48:	9636                	add	a2,a2,a3
   11e4a:	00ca2787          	flw	fa5,12(s4)
   11e4e:	0a41                	addi	s4,s4,16
   11e50:	b306d457          	vfmacc.vf	v8,fa3,v16
   11e54:	02066807          	vle32.v	v16,(a2)
   11e58:	9636                	add	a2,a2,a3
   11e5a:	b3875457          	vfmacc.vf	v8,fa4,v24
   11e5e:	b307d457          	vfmacc.vf	v8,fa5,v16
   11e62:	fd4513e3          	bne	a0,s4,11e28 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x162>
   11e66:	016f0633          	add	a2,t5,s6
   11e6a:	02066427          	vse32.v	v8,(a2)
   11e6e:	015f8633          	add	a2,t6,s5
   11e72:	40c70a3b          	subw	s4,a4,a2
   11e76:	01fa4463          	blt	s4,t6,11e7e <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1b8>
   11e7a:	8ab2                	mv	s5,a2
   11e7c:	bf69                	j	11e16 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x150>
   11e7e:	01fa8b3b          	addw	s6,s5,t6
   11e82:	4159863b          	subw	a2,s3,s5
   11e86:	09265363          	bge	a2,s2,11f0c <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x246>
   11e8a:	0e965363          	bge	a2,s1,11f70 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x2aa>
   11e8e:	f0050593          	addi	a1,a0,-256
   11e92:	14eb5163          	bge	s6,a4,11fd4 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x30e>
   11e96:	4167063b          	subw	a2,a4,s6
   11e9a:	00060b9b          	sext.w	s7,a2
   11e9e:	00c2d463          	bge	t0,a2,11ea6 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1e0>
   11ea2:	00028b9b          	sext.w	s7,t0
   11ea6:	0d0bf057          	vsetvli	zero,s7,e32,m1,ta,ma
   11eaa:	5e0030d7          	vmv.v.i	v1,0
   11eae:	002b1c13          	slli	s8,s6,0x2
   11eb2:	018e8633          	add	a2,t4,s8
   11eb6:	8aae                	mv	s5,a1
   11eb8:	02066107          	vle32.v	v2,(a2)
   11ebc:	000aa787          	flw	fa5,0(s5)
   11ec0:	9636                	add	a2,a2,a3
   11ec2:	02066207          	vle32.v	v4,(a2)
   11ec6:	004aa687          	flw	fa3,4(s5)
   11eca:	9636                	add	a2,a2,a3
   11ecc:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   11ed0:	02066187          	vle32.v	v3,(a2)
   11ed4:	008aa707          	flw	fa4,8(s5)
   11ed8:	9636                	add	a2,a2,a3
   11eda:	02066107          	vle32.v	v2,(a2)
   11ede:	00caa787          	flw	fa5,12(s5)
   11ee2:	b246d0d7          	vfmacc.vf	v1,fa3,v4
   11ee6:	0ac1                	addi	s5,s5,16
   11ee8:	9636                	add	a2,a2,a3
   11eea:	b23750d7          	vfmacc.vf	v1,fa4,v3
   11eee:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   11ef2:	fd5513e3          	bne	a0,s5,11eb8 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1f2>
   11ef6:	018f0633          	add	a2,t5,s8
   11efa:	020660a7          	vse32.v	v1,(a2)
   11efe:	016b8b3b          	addw	s6,s7,s6
   11f02:	f8eb4ae3          	blt	s6,a4,11e96 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1d0>
   11f06:	0d307fd7          	vsetvli	t6,zero,e32,m8,ta,ma
   11f0a:	bdc9                	j	11ddc <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x116>
   11f0c:	0d207957          	vsetvli	s2,zero,e32,m4,ta,ma
   11f10:	5e003257          	vmv.v.i	v4,0
   11f14:	002b1a93          	slli	s5,s6,0x2
   11f18:	015e8633          	add	a2,t4,s5
   11f1c:	8a72                	mv	s4,t3
   11f1e:	02066407          	vle32.v	v8,(a2)
   11f22:	000a2787          	flw	fa5,0(s4)
   11f26:	9636                	add	a2,a2,a3
   11f28:	02066807          	vle32.v	v16,(a2)
   11f2c:	004a2687          	flw	fa3,4(s4)
   11f30:	9636                	add	a2,a2,a3
   11f32:	b287d257          	vfmacc.vf	v4,fa5,v8
   11f36:	02066607          	vle32.v	v12,(a2)
   11f3a:	008a2707          	flw	fa4,8(s4)
   11f3e:	9636                	add	a2,a2,a3
   11f40:	02066407          	vle32.v	v8,(a2)
   11f44:	00ca2787          	flw	fa5,12(s4)
   11f48:	b306d257          	vfmacc.vf	v4,fa3,v16
   11f4c:	0a41                	addi	s4,s4,16
   11f4e:	9636                	add	a2,a2,a3
   11f50:	b2c75257          	vfmacc.vf	v4,fa4,v12
   11f54:	b287d257          	vfmacc.vf	v4,fa5,v8
   11f58:	fd4513e3          	bne	a0,s4,11f1e <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x258>
   11f5c:	015f0633          	add	a2,t5,s5
   11f60:	02066227          	vse32.v	v4,(a2)
   11f64:	01690b3b          	addw	s6,s2,s6
   11f68:	4167063b          	subw	a2,a4,s6
   11f6c:	f29641e3          	blt	a2,s1,11e8e <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1c8>
   11f70:	0d1074d7          	vsetvli	s1,zero,e32,m2,ta,ma
   11f74:	5e003157          	vmv.v.i	v2,0
   11f78:	002b1a93          	slli	s5,s6,0x2
   11f7c:	015e8633          	add	a2,t4,s5
   11f80:	8a72                	mv	s4,t3
   11f82:	02066207          	vle32.v	v4,(a2)
   11f86:	000a2787          	flw	fa5,0(s4)
   11f8a:	9636                	add	a2,a2,a3
   11f8c:	02066407          	vle32.v	v8,(a2)
   11f90:	004a2687          	flw	fa3,4(s4)
   11f94:	9636                	add	a2,a2,a3
   11f96:	b247d157          	vfmacc.vf	v2,fa5,v4
   11f9a:	02066307          	vle32.v	v6,(a2)
   11f9e:	008a2707          	flw	fa4,8(s4)
   11fa2:	9636                	add	a2,a2,a3
   11fa4:	02066207          	vle32.v	v4,(a2)
   11fa8:	00ca2787          	flw	fa5,12(s4)
   11fac:	b286d157          	vfmacc.vf	v2,fa3,v8
   11fb0:	0a41                	addi	s4,s4,16
   11fb2:	9636                	add	a2,a2,a3
   11fb4:	b2675157          	vfmacc.vf	v2,fa4,v6
   11fb8:	b247d157          	vfmacc.vf	v2,fa5,v4
   11fbc:	fd4513e3          	bne	a0,s4,11f82 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x2bc>
   11fc0:	015f0633          	add	a2,t5,s5
   11fc4:	02066127          	vse32.v	v2,(a2)
   11fc8:	01648b3b          	addw	s6,s1,s6
   11fcc:	f0050593          	addi	a1,a0,-256
   11fd0:	eceb43e3          	blt	s6,a4,11e96 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x1d0>
   11fd4:	0d307fd7          	vsetvli	t6,zero,e32,m8,ta,ma
   11fd8:	b511                	j	11ddc <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x116>
   11fda:	863a                	mv	a2,a4
   11fdc:	4b01                	li	s6,0
   11fde:	bbed                	j	11dd8 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)+0x112>
   11fe0:	8082                	ret

0000000000011fe2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)>:
   11fe2:	5ed05963          	blez	a3,125d4 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5f2>
   11fe6:	7159                	addi	sp,sp,-112
   11fe8:	0c107f57          	vsetvli	t5,zero,e8,m2,ta,ma
   11fec:	e8ce                	sd	s3,80(sp)
   11fee:	ffc7099b          	addiw	s3,a4,-4
   11ff2:	06a2                	slli	a3,a3,0x8
   11ff4:	0c1f77d7          	vsetvli	a5,t5,e8,m2,ta,ma
   11ff8:	f4a2                	sd	s0,104(sp)
   11ffa:	f0a6                	sd	s1,96(sp)
   11ffc:	8432                	mv	s0,a2
   11ffe:	001f149b          	slliw	s1,t5,0x1
   12002:	ffc9f993          	andi	s3,s3,-4
   12006:	0027561b          	srliw	a2,a4,0x2
   1200a:	ecca                	sd	s2,88(sp)
   1200c:	fc5a                	sd	s6,56(sp)
   1200e:	f85e                	sd	s7,48(sp)
   12010:	82ae                	mv	t0,a1
   12012:	e4d2                	sd	s4,72(sp)
   12014:	00d405b3          	add	a1,s0,a3
   12018:	e0d6                	sd	s5,64(sp)
   1201a:	f462                	sd	s8,40(sp)
   1201c:	f066                	sd	s9,32(sp)
   1201e:	ec6a                	sd	s10,24(sp)
   12020:	e86e                	sd	s11,16(sp)
   12022:	83aa                	mv	t2,a0
   12024:	00249913          	slli	s2,s1,0x2
   12028:	00078b9b          	sext.w	s7,a5
   1202c:	2991                	addiw	s3,s3,4
   1202e:	0612                	slli	a2,a2,0x4
   12030:	00271893          	slli	a7,a4,0x2
   12034:	03f00b13          	li	s6,63
   12038:	0c6076d7          	vsetvli	a3,zero,e8,mf4,ta,ma
   1203c:	00871813          	slli	a6,a4,0x8
   12040:	04000513          	li	a0,64
   12044:	56954563          	blt	a0,s1,125ae <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5cc>
   12048:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   1204c:	5e003057          	vmv.v.i	v0,0
   12050:	4d8d                	li	s11,3
   12052:	04000d13          	li	s10,64
   12056:	e42e                	sd	a1,8(sp)
   12058:	8536                	mv	a0,a3
   1205a:	002b9c93          	slli	s9,s7,0x2
   1205e:	4c01                	li	s8,0
   12060:	4a81                	li	s5,0
   12062:	00760a33          	add	s4,a2,t2
   12066:	8fc6                	mv	t6,a7
   12068:	9e03b857          	vmv8r.v	v16,v0
   1206c:	9e03b457          	vmv8r.v	v8,v0
   12070:	14edd063          	bge	s11,a4,121b0 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x1ce>
   12074:	018288b3          	add	a7,t0,s8
   12078:	019285b3          	add	a1,t0,s9
   1207c:	869e                	mv	a3,t2
   1207e:	e056                	sd	s5,0(sp)
   12080:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   12084:	0208ec07          	vle32.v	v24,(a7)
   12088:	0006a607          	flw	fa2,0(a3)
   1208c:	10088313          	addi	t1,a7,256
   12090:	0046a687          	flw	fa3,4(a3)
   12094:	0086a707          	flw	fa4,8(a3)
   12098:	30088a93          	addi	s5,a7,768
   1209c:	b3865857          	vfmacc.vf	v16,fa2,v24
   120a0:	02036c07          	vle32.v	v24,(t1)
   120a4:	20088313          	addi	t1,a7,512
   120a8:	00c6a787          	flw	fa5,12(a3)
   120ac:	10058e93          	addi	t4,a1,256
   120b0:	20058e13          	addi	t3,a1,512
   120b4:	06c1                	addi	a3,a3,16
   120b6:	b386d857          	vfmacc.vf	v16,fa3,v24
   120ba:	02036c07          	vle32.v	v24,(t1)
   120be:	30058313          	addi	t1,a1,768
   120c2:	40088893          	addi	a7,a7,1024
   120c6:	b3875857          	vfmacc.vf	v16,fa4,v24
   120ca:	020aec07          	vle32.v	v24,(s5)
   120ce:	b387d857          	vfmacc.vf	v16,fa5,v24
   120d2:	0205ec07          	vle32.v	v24,(a1)
   120d6:	40058593          	addi	a1,a1,1024
   120da:	b3865457          	vfmacc.vf	v8,fa2,v24
   120de:	020eec07          	vle32.v	v24,(t4)
   120e2:	b386d457          	vfmacc.vf	v8,fa3,v24
   120e6:	020e6c07          	vle32.v	v24,(t3)
   120ea:	b3875457          	vfmacc.vf	v8,fa4,v24
   120ee:	02036c07          	vle32.v	v24,(t1)
   120f2:	b387d457          	vfmacc.vf	v8,fa5,v24
   120f6:	f94697e3          	bne	a3,s4,12084 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0xa2>
   120fa:	6a82                	ld	s5,0(sp)
   120fc:	86ce                	mv	a3,s3
   120fe:	06e6de63          	bge	a3,a4,1217a <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x198>
   12102:	00869593          	slli	a1,a3,0x8
   12106:	00b288b3          	add	a7,t0,a1
   1210a:	01888333          	add	t1,a7,s8
   1210e:	02036c07          	vle32.v	v24,(t1)
   12112:	01988e33          	add	t3,a7,s9
   12116:	00269893          	slli	a7,a3,0x2
   1211a:	989e                	add	a7,a7,t2
   1211c:	0008a787          	flw	fa5,0(a7)
   12120:	0016831b          	addiw	t1,a3,1
   12124:	b387d857          	vfmacc.vf	v16,fa5,v24
   12128:	020e6c07          	vle32.v	v24,(t3)
   1212c:	b387d457          	vfmacc.vf	v8,fa5,v24
   12130:	04e35563          	bge	t1,a4,1217a <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x198>
   12134:	10058313          	addi	t1,a1,256
   12138:	9316                	add	t1,t1,t0
   1213a:	01830e33          	add	t3,t1,s8
   1213e:	020e6c07          	vle32.v	v24,(t3)
   12142:	0048a787          	flw	fa5,4(a7)
   12146:	9366                	add	t1,t1,s9
   12148:	2689                	addiw	a3,a3,2
   1214a:	b387d857          	vfmacc.vf	v16,fa5,v24
   1214e:	02036c07          	vle32.v	v24,(t1)
   12152:	b387d457          	vfmacc.vf	v8,fa5,v24
   12156:	02e6d263          	bge	a3,a4,1217a <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x198>
   1215a:	20058593          	addi	a1,a1,512
   1215e:	9596                	add	a1,a1,t0
   12160:	018586b3          	add	a3,a1,s8
   12164:	0206ec07          	vle32.v	v24,(a3)
   12168:	0088a787          	flw	fa5,8(a7)
   1216c:	95e6                	add	a1,a1,s9
   1216e:	b387d857          	vfmacc.vf	v16,fa5,v24
   12172:	0205ec07          	vle32.v	v24,(a1)
   12176:	b387d457          	vfmacc.vf	v8,fa5,v24
   1217a:	018406b3          	add	a3,s0,s8
   1217e:	0206e827          	vse32.v	v16,(a3)
   12182:	019406b3          	add	a3,s0,s9
   12186:	01548abb          	addw	s5,s1,s5
   1218a:	415d0e3b          	subw	t3,s10,s5
   1218e:	9c4a                	add	s8,s8,s2
   12190:	9cca                	add	s9,s9,s2
   12192:	0206e427          	vse32.v	v8,(a3)
   12196:	ec9e59e3          	bge	t3,s1,12068 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x86>
   1219a:	88fe                	mv	a7,t6
   1219c:	015b5e63          	bge	s6,s5,121b8 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x1d6>
   121a0:	66a2                	ld	a3,8(sp)
   121a2:	10040413          	addi	s0,s0,256
   121a6:	22868063          	beq	a3,s0,123c6 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x3e4>
   121aa:	92c2                	add	t0,t0,a6
   121ac:	93fe                	add	t2,t2,t6
   121ae:	b575                	j	1205a <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x78>
   121b0:	4681                	li	a3,0
   121b2:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   121b6:	b7a1                	j	120fe <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x11c>
   121b8:	65a2                	ld	a1,8(sp)
   121ba:	86aa                	mv	a3,a0
   121bc:	0c007357          	vsetvli	t1,zero,e8,m1,ta,ma
   121c0:	0c707557          	vsetvli	a0,zero,e8,mf2,ta,ma
   121c4:	2fee4d63          	blt	t3,t5,124be <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x4dc>
   121c8:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   121cc:	5e003057          	vmv.v.i	v0,0
   121d0:	4c0d                	li	s8,3
   121d2:	00760eb3          	add	t4,a2,t2
   121d6:	9e03b457          	vmv8r.v	v8,v0
   121da:	04000a13          	li	s4,64
   121de:	0cec5a63          	bge	s8,a4,122b2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2d0>
   121e2:	002a9d13          	slli	s10,s5,0x2
   121e6:	005d0fb3          	add	t6,s10,t0
   121ea:	8e1e                	mv	t3,t2
   121ec:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   121f0:	020fec07          	vle32.v	v24,(t6)
   121f4:	000e2787          	flw	fa5,0(t3)
   121f8:	100f8c93          	addi	s9,t6,256
   121fc:	020ce807          	vle32.v	v16,(s9)
   12200:	004e2687          	flw	fa3,4(t3)
   12204:	200f8c93          	addi	s9,t6,512
   12208:	b387d457          	vfmacc.vf	v8,fa5,v24
   1220c:	020cec07          	vle32.v	v24,(s9)
   12210:	008e2707          	flw	fa4,8(t3)
   12214:	300f8c93          	addi	s9,t6,768
   12218:	00ce2787          	flw	fa5,12(t3)
   1221c:	0e41                	addi	t3,t3,16
   1221e:	b306d457          	vfmacc.vf	v8,fa3,v16
   12222:	020ce807          	vle32.v	v16,(s9)
   12226:	400f8f93          	addi	t6,t6,1024
   1222a:	b3875457          	vfmacc.vf	v8,fa4,v24
   1222e:	b307d457          	vfmacc.vf	v8,fa5,v16
   12232:	fbde1fe3          	bne	t3,t4,121f0 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x20e>
   12236:	8e4e                	mv	t3,s3
   12238:	04ee5f63          	bge	t3,a4,12296 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2b4>
   1223c:	006e1c93          	slli	s9,t3,0x6
   12240:	019a8fb3          	add	t6,s5,s9
   12244:	0f8a                	slli	t6,t6,0x2
   12246:	9f96                	add	t6,t6,t0
   12248:	020fe807          	vle32.v	v16,(t6)
   1224c:	002e1f93          	slli	t6,t3,0x2
   12250:	9f9e                	add	t6,t6,t2
   12252:	000fa787          	flw	fa5,0(t6)
   12256:	001e0d9b          	addiw	s11,t3,1
   1225a:	b307d457          	vfmacc.vf	v8,fa5,v16
   1225e:	02eddc63          	bge	s11,a4,12296 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2b4>
   12262:	040c8d93          	addi	s11,s9,64
   12266:	9dd6                	add	s11,s11,s5
   12268:	0d8a                	slli	s11,s11,0x2
   1226a:	9d96                	add	s11,s11,t0
   1226c:	020de807          	vle32.v	v16,(s11)
   12270:	004fa787          	flw	fa5,4(t6)
   12274:	2e09                	addiw	t3,t3,2
   12276:	b307d457          	vfmacc.vf	v8,fa5,v16
   1227a:	00ee5e63          	bge	t3,a4,12296 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2b4>
   1227e:	019a8e33          	add	t3,s5,s9
   12282:	0e0a                	slli	t3,t3,0x2
   12284:	200e0e13          	addi	t3,t3,512
   12288:	9e16                	add	t3,t3,t0
   1228a:	020e6807          	vle32.v	v16,(t3)
   1228e:	008fa787          	flw	fa5,8(t6)
   12292:	b307d457          	vfmacc.vf	v8,fa5,v16
   12296:	9d22                	add	s10,s10,s0
   12298:	020d6427          	vse32.v	v8,(s10)
   1229c:	015f0e33          	add	t3,t5,s5
   122a0:	41ca0fbb          	subw	t6,s4,t3
   122a4:	01efcd63          	blt	t6,t5,122be <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2dc>
   122a8:	9e03b457          	vmv8r.v	v8,v0
   122ac:	8af2                	mv	s5,t3
   122ae:	f2ec4ae3          	blt	s8,a4,121e2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x200>
   122b2:	4e01                	li	t3,0
   122b4:	002a9d13          	slli	s10,s5,0x2
   122b8:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   122bc:	bfb5                	j	12238 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x256>
   122be:	41ea0e3b          	subw	t3,s4,t5
   122c2:	415e0e3b          	subw	t3,t3,s5
   122c6:	015f0abb          	addw	s5,t5,s5
   122ca:	1e6e5c63          	bge	t3,t1,124c2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x4e0>
   122ce:	10ae5a63          	bge	t3,a0,123e2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x400>
   122d2:	0f5b4463          	blt	s6,s5,123ba <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x3d8>
   122d6:	04000d13          	li	s10,64
   122da:	4c8d                	li	s9,3
   122dc:	00760fb3          	add	t6,a2,t2
   122e0:	415d053b          	subw	a0,s10,s5
   122e4:	00050c1b          	sext.w	s8,a0
   122e8:	00a6d463          	bge	a3,a0,122f0 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x30e>
   122ec:	00068c1b          	sext.w	s8,a3
   122f0:	0d0c7057          	vsetvli	zero,s8,e32,m1,ta,ma
   122f4:	5e0030d7          	vmv.v.i	v1,0
   122f8:	2aecd763          	bge	s9,a4,125a6 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5c4>
   122fc:	002a9a13          	slli	s4,s5,0x2
   12300:	005a0e33          	add	t3,s4,t0
   12304:	831e                	mv	t1,t2
   12306:	020e6107          	vle32.v	v2,(t3)
   1230a:	00032787          	flw	fa5,0(t1)
   1230e:	100e0e93          	addi	t4,t3,256
   12312:	020ee207          	vle32.v	v4,(t4)
   12316:	00432687          	flw	fa3,4(t1)
   1231a:	200e0e93          	addi	t4,t3,512
   1231e:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   12322:	020ee187          	vle32.v	v3,(t4)
   12326:	00832707          	flw	fa4,8(t1)
   1232a:	300e0e93          	addi	t4,t3,768
   1232e:	020ee107          	vle32.v	v2,(t4)
   12332:	00c32787          	flw	fa5,12(t1)
   12336:	b246d0d7          	vfmacc.vf	v1,fa3,v4
   1233a:	0341                	addi	t1,t1,16
   1233c:	400e0e13          	addi	t3,t3,1024
   12340:	b23750d7          	vfmacc.vf	v1,fa4,v3
   12344:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   12348:	fbf31fe3          	bne	t1,t6,12306 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x324>
   1234c:	834e                	mv	t1,s3
   1234e:	04e35f63          	bge	t1,a4,123ac <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x3ca>
   12352:	00631e93          	slli	t4,t1,0x6
   12356:	015e8e33          	add	t3,t4,s5
   1235a:	0e0a                	slli	t3,t3,0x2
   1235c:	9e16                	add	t3,t3,t0
   1235e:	020e6107          	vle32.v	v2,(t3)
   12362:	00231e13          	slli	t3,t1,0x2
   12366:	9e1e                	add	t3,t3,t2
   12368:	000e2787          	flw	fa5,0(t3)
   1236c:	00130d9b          	addiw	s11,t1,1
   12370:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   12374:	02eddc63          	bge	s11,a4,123ac <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x3ca>
   12378:	040e8d93          	addi	s11,t4,64
   1237c:	9dd6                	add	s11,s11,s5
   1237e:	0d8a                	slli	s11,s11,0x2
   12380:	9d96                	add	s11,s11,t0
   12382:	020de107          	vle32.v	v2,(s11)
   12386:	004e2787          	flw	fa5,4(t3)
   1238a:	2309                	addiw	t1,t1,2
   1238c:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   12390:	00e35e63          	bge	t1,a4,123ac <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x3ca>
   12394:	01da8333          	add	t1,s5,t4
   12398:	030a                	slli	t1,t1,0x2
   1239a:	20030313          	addi	t1,t1,512
   1239e:	9316                	add	t1,t1,t0
   123a0:	02036107          	vle32.v	v2,(t1)
   123a4:	008e2787          	flw	fa5,8(t3)
   123a8:	b227d0d7          	vfmacc.vf	v1,fa5,v2
   123ac:	9a22                	add	s4,s4,s0
   123ae:	020a60a7          	vse32.v	v1,(s4)
   123b2:	015c0abb          	addw	s5,s8,s5
   123b6:	f35b55e3          	bge	s6,s5,122e0 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2fe>
   123ba:	10040413          	addi	s0,s0,256
   123be:	92c2                	add	t0,t0,a6
   123c0:	93c6                	add	t2,t2,a7
   123c2:	c6859fe3          	bne	a1,s0,12040 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5e>
   123c6:	7426                	ld	s0,104(sp)
   123c8:	7486                	ld	s1,96(sp)
   123ca:	6966                	ld	s2,88(sp)
   123cc:	69c6                	ld	s3,80(sp)
   123ce:	6a26                	ld	s4,72(sp)
   123d0:	6a86                	ld	s5,64(sp)
   123d2:	7b62                	ld	s6,56(sp)
   123d4:	7bc2                	ld	s7,48(sp)
   123d6:	7c22                	ld	s8,40(sp)
   123d8:	7c82                	ld	s9,32(sp)
   123da:	6d62                	ld	s10,24(sp)
   123dc:	6dc2                	ld	s11,16(sp)
   123de:	6165                	addi	sp,sp,112
   123e0:	8082                	ret
   123e2:	0d107557          	vsetvli	a0,zero,e32,m2,ta,ma
   123e6:	4e0d                	li	t3,3
   123e8:	5e003157          	vmv.v.i	v2,0
   123ec:	1cee5c63          	bge	t3,a4,125c4 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5e2>
   123f0:	00275c1b          	srliw	s8,a4,0x2
   123f4:	0c12                	slli	s8,s8,0x4
   123f6:	002a9a13          	slli	s4,s5,0x2
   123fa:	9c1e                	add	s8,s8,t2
   123fc:	005a0eb3          	add	t4,s4,t0
   12400:	ffc70c9b          	addiw	s9,a4,-4
   12404:	8e1e                	mv	t3,t2
   12406:	020ee207          	vle32.v	v4,(t4)
   1240a:	000e2787          	flw	fa5,0(t3)
   1240e:	100e8f93          	addi	t6,t4,256
   12412:	020fe407          	vle32.v	v8,(t6)
   12416:	004e2687          	flw	fa3,4(t3)
   1241a:	200e8f93          	addi	t6,t4,512
   1241e:	b247d157          	vfmacc.vf	v2,fa5,v4
   12422:	020fe307          	vle32.v	v6,(t6)
   12426:	008e2707          	flw	fa4,8(t3)
   1242a:	300e8f93          	addi	t6,t4,768
   1242e:	020fe207          	vle32.v	v4,(t6)
   12432:	00ce2787          	flw	fa5,12(t3)
   12436:	b286d157          	vfmacc.vf	v2,fa3,v8
   1243a:	0e41                	addi	t3,t3,16
   1243c:	400e8e93          	addi	t4,t4,1024
   12440:	b2675157          	vfmacc.vf	v2,fa4,v6
   12444:	b247d157          	vfmacc.vf	v2,fa5,v4
   12448:	fb8e1fe3          	bne	t3,s8,12406 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x424>
   1244c:	ffccfe13          	andi	t3,s9,-4
   12450:	2e11                	addiw	t3,t3,4
   12452:	06ee5063          	bge	t3,a4,124b2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x4d0>
   12456:	006e1f93          	slli	t6,t3,0x6
   1245a:	015f8eb3          	add	t4,t6,s5
   1245e:	0e8a                	slli	t4,t4,0x2
   12460:	9e96                	add	t4,t4,t0
   12462:	020ee207          	vle32.v	v4,(t4)
   12466:	002e1c13          	slli	s8,t3,0x2
   1246a:	9c1e                	add	s8,s8,t2
   1246c:	000c2787          	flw	fa5,0(s8)
   12470:	001e0e9b          	addiw	t4,t3,1
   12474:	b247d157          	vfmacc.vf	v2,fa5,v4
   12478:	02eedd63          	bge	t4,a4,124b2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x4d0>
   1247c:	040f8e93          	addi	t4,t6,64
   12480:	9ed6                	add	t4,t4,s5
   12482:	0e8a                	slli	t4,t4,0x2
   12484:	9e96                	add	t4,t4,t0
   12486:	020ee207          	vle32.v	v4,(t4)
   1248a:	004c2787          	flw	fa5,4(s8)
   1248e:	002e0e9b          	addiw	t4,t3,2
   12492:	b247d157          	vfmacc.vf	v2,fa5,v4
   12496:	00eede63          	bge	t4,a4,124b2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x4d0>
   1249a:	01fa8e33          	add	t3,s5,t6
   1249e:	0e0a                	slli	t3,t3,0x2
   124a0:	200e0e13          	addi	t3,t3,512
   124a4:	9e16                	add	t3,t3,t0
   124a6:	020e6207          	vle32.v	v4,(t3)
   124aa:	008c2787          	flw	fa5,8(s8)
   124ae:	b247d157          	vfmacc.vf	v2,fa5,v4
   124b2:	9a22                	add	s4,s4,s0
   124b4:	020a6127          	vse32.v	v2,(s4)
   124b8:	01550abb          	addw	s5,a0,s5
   124bc:	bd19                	j	122d2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2f0>
   124be:	0e6e4e63          	blt	t3,t1,125ba <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5d8>
   124c2:	0d207357          	vsetvli	t1,zero,e32,m4,ta,ma
   124c6:	4e8d                	li	t4,3
   124c8:	5e003257          	vmv.v.i	v4,0
   124cc:	10eed063          	bge	t4,a4,125cc <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5ea>
   124d0:	00275c9b          	srliw	s9,a4,0x2
   124d4:	0c92                	slli	s9,s9,0x4
   124d6:	002a9a13          	slli	s4,s5,0x2
   124da:	9c9e                	add	s9,s9,t2
   124dc:	005a0fb3          	add	t6,s4,t0
   124e0:	ffc70d1b          	addiw	s10,a4,-4
   124e4:	8e9e                	mv	t4,t2
   124e6:	020fe407          	vle32.v	v8,(t6)
   124ea:	000ea787          	flw	fa5,0(t4)
   124ee:	100f8c13          	addi	s8,t6,256
   124f2:	020c6807          	vle32.v	v16,(s8)
   124f6:	004ea687          	flw	fa3,4(t4)
   124fa:	200f8c13          	addi	s8,t6,512
   124fe:	b287d257          	vfmacc.vf	v4,fa5,v8
   12502:	020c6607          	vle32.v	v12,(s8)
   12506:	008ea707          	flw	fa4,8(t4)
   1250a:	300f8c13          	addi	s8,t6,768
   1250e:	020c6407          	vle32.v	v8,(s8)
   12512:	00cea787          	flw	fa5,12(t4)
   12516:	b306d257          	vfmacc.vf	v4,fa3,v16
   1251a:	0ec1                	addi	t4,t4,16
   1251c:	400f8f93          	addi	t6,t6,1024
   12520:	b2c75257          	vfmacc.vf	v4,fa4,v12
   12524:	b287d257          	vfmacc.vf	v4,fa5,v8
   12528:	fb9e9fe3          	bne	t4,s9,124e6 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x504>
   1252c:	ffcd7f93          	andi	t6,s10,-4
   12530:	2f91                	addiw	t6,t6,4
   12532:	04efde63          	bge	t6,a4,1258e <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5ac>
   12536:	006f9e93          	slli	t4,t6,0x6
   1253a:	015e8c33          	add	s8,t4,s5
   1253e:	0c0a                	slli	s8,s8,0x2
   12540:	9c16                	add	s8,s8,t0
   12542:	020c6407          	vle32.v	v8,(s8)
   12546:	002f9c13          	slli	s8,t6,0x2
   1254a:	9c1e                	add	s8,s8,t2
   1254c:	000c2787          	flw	fa5,0(s8)
   12550:	001f8c9b          	addiw	s9,t6,1
   12554:	b287d257          	vfmacc.vf	v4,fa5,v8
   12558:	02ecdb63          	bge	s9,a4,1258e <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5ac>
   1255c:	040e8c93          	addi	s9,t4,64
   12560:	9cd6                	add	s9,s9,s5
   12562:	0c8a                	slli	s9,s9,0x2
   12564:	9c96                	add	s9,s9,t0
   12566:	020ce407          	vle32.v	v8,(s9)
   1256a:	004c2787          	flw	fa5,4(s8)
   1256e:	2f89                	addiw	t6,t6,2
   12570:	b287d257          	vfmacc.vf	v4,fa5,v8
   12574:	00efdd63          	bge	t6,a4,1258e <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x5ac>
   12578:	9ed6                	add	t4,t4,s5
   1257a:	0e8a                	slli	t4,t4,0x2
   1257c:	200e8e93          	addi	t4,t4,512
   12580:	9e96                	add	t4,t4,t0
   12582:	020ee407          	vle32.v	v8,(t4)
   12586:	008c2787          	flw	fa5,8(s8)
   1258a:	b287d257          	vfmacc.vf	v4,fa5,v8
   1258e:	9a22                	add	s4,s4,s0
   12590:	020a6227          	vse32.v	v4,(s4)
   12594:	01530abb          	addw	s5,t1,s5
   12598:	04000e13          	li	t3,64
   1259c:	415e0e3b          	subw	t3,t3,s5
   125a0:	d2ae49e3          	blt	t3,a0,122d2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2f0>
   125a4:	bd3d                	j	123e2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x400>
   125a6:	4301                	li	t1,0
   125a8:	002a9a13          	slli	s4,s5,0x2
   125ac:	b34d                	j	1234e <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x36c>
   125ae:	0d307f57          	vsetvli	t5,zero,e32,m8,ta,ma
   125b2:	04000e13          	li	t3,64
   125b6:	4a81                	li	s5,0
   125b8:	b111                	j	121bc <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x1da>
   125ba:	d0ae4ee3          	blt	t3,a0,122d6 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x2f4>
   125be:	0d107057          	vsetvli	zero,zero,e32,m2,ta,ma
   125c2:	b515                	j	123e6 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x404>
   125c4:	4e01                	li	t3,0
   125c6:	002a9a13          	slli	s4,s5,0x2
   125ca:	b561                	j	12452 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x470>
   125cc:	4f81                	li	t6,0
   125ce:	002a9a13          	slli	s4,s5,0x2
   125d2:	b785                	j	12532 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)+0x550>
   125d4:	8082                	ret

00000000000125d6 <attention_bmm_rvv_f32>:
   125d6:	7159                	addi	sp,sp,-112
   125d8:	e8ce                	sd	s3,80(sp)
   125da:	fc078893          	addi	a7,a5,-64
   125de:	89ba                	mv	s3,a4
   125e0:	177d                	addi	a4,a4,-1
   125e2:	00173713          	seqz	a4,a4
   125e6:	0018b893          	seqz	a7,a7
   125ea:	011778b3          	and	a7,a4,a7
   125ee:	18089563          	bnez	a7,12778 <attention_bmm_rvv_f32+0x1a2>
   125f2:	fc080893          	addi	a7,a6,-64
   125f6:	0018b893          	seqz	a7,a7
   125fa:	01177733          	and	a4,a4,a7
   125fe:	16071963          	bnez	a4,12770 <attention_bmm_rvv_f32+0x19a>
   12602:	fc5a                	sd	s6,56(sp)
   12604:	8b36                	mv	s6,a3
   12606:	14d05f63          	blez	a3,12764 <attention_bmm_rvv_f32+0x18e>
   1260a:	15305d63          	blez	s3,12764 <attention_bmm_rvv_f32+0x18e>
   1260e:	15005b63          	blez	a6,12764 <attention_bmm_rvv_f32+0x18e>
   12612:	f4a2                	sd	s0,104(sp)
   12614:	e0d6                	sd	s5,64(sp)
   12616:	8432                	mv	s0,a2
   12618:	00279a93          	slli	s5,a5,0x2
   1261c:	00281613          	slli	a2,a6,0x2
   12620:	ec6a                	sd	s10,24(sp)
   12622:	03098e33          	mul	t3,s3,a6
   12626:	f0a6                	sd	s1,96(sp)
   12628:	ffc7849b          	addiw	s1,a5,-4
   1262c:	e4d2                	sd	s4,72(sp)
   1262e:	98f1                	andi	s1,s1,-4
   12630:	0027da1b          	srliw	s4,a5,0x2
   12634:	f85e                	sd	s7,48(sp)
   12636:	02c78d33          	mul	s10,a5,a2
   1263a:	f462                	sd	s8,40(sp)
   1263c:	ecca                	sd	s2,88(sp)
   1263e:	f066                	sd	s9,32(sp)
   12640:	e86e                	sd	s11,16(sp)
   12642:	8fae                	mv	t6,a1
   12644:	2491                	addiw	s1,s1,4
   12646:	03598f33          	mul	t5,s3,s5
   1264a:	0a12                	slli	s4,s4,0x4
   1264c:	4c01                	li	s8,0
   1264e:	4b81                	li	s7,0
   12650:	470d                	li	a4,3
   12652:	88aa                	mv	a7,a0
   12654:	8946                	mv	s2,a7
   12656:	8dda                	mv	s11,s6
   12658:	8ce2                	mv	s9,s8
   1265a:	8b72                	mv	s6,t3
   1265c:	83de                	mv	t2,s7
   1265e:	8e46                	mv	t3,a7
   12660:	4881                	li	a7,0
   12662:	4301                	li	t1,0
   12664:	012a05b3          	add	a1,s4,s2
   12668:	e446                	sd	a7,8(sp)
   1266a:	406806bb          	subw	a3,a6,t1
   1266e:	0d26f6d7          	vsetvli	a3,a3,e32,m4,ta,ma
   12672:	5e003257          	vmv.v.i	v4,0
   12676:	0ef75b63          	bge	a4,a5,1276c <attention_bmm_rvv_f32+0x196>
   1267a:	00231513          	slli	a0,t1,0x2
   1267e:	957e                	add	a0,a0,t6
   12680:	88ca                	mv	a7,s2
   12682:	02056407          	vle32.v	v8,(a0)
   12686:	0008a787          	flw	fa5,0(a7)
   1268a:	9532                	add	a0,a0,a2
   1268c:	02056807          	vle32.v	v16,(a0)
   12690:	0048a687          	flw	fa3,4(a7)
   12694:	9532                	add	a0,a0,a2
   12696:	b287d257          	vfmacc.vf	v4,fa5,v8
   1269a:	02056607          	vle32.v	v12,(a0)
   1269e:	0088a707          	flw	fa4,8(a7)
   126a2:	9532                	add	a0,a0,a2
   126a4:	02056407          	vle32.v	v8,(a0)
   126a8:	00c8a787          	flw	fa5,12(a7)
   126ac:	b306d257          	vfmacc.vf	v4,fa3,v16
   126b0:	08c1                	addi	a7,a7,16
   126b2:	9532                	add	a0,a0,a2
   126b4:	b2c75257          	vfmacc.vf	v4,fa4,v12
   126b8:	b287d257          	vfmacc.vf	v4,fa5,v8
   126bc:	fcb893e3          	bne	a7,a1,12682 <attention_bmm_rvv_f32+0xac>
   126c0:	88a6                	mv	a7,s1
   126c2:	04f8dd63          	bge	a7,a5,1271c <attention_bmm_rvv_f32+0x146>
   126c6:	03180533          	mul	a0,a6,a7
   126ca:	00289293          	slli	t0,a7,0x2
   126ce:	92ca                	add	t0,t0,s2
   126d0:	0002a787          	flw	fa5,0(t0)
   126d4:	00188b9b          	addiw	s7,a7,1
   126d8:	00650eb3          	add	t4,a0,t1
   126dc:	0e8a                	slli	t4,t4,0x2
   126de:	9efe                	add	t4,t4,t6
   126e0:	020ee407          	vle32.v	v8,(t4)
   126e4:	b287d257          	vfmacc.vf	v4,fa5,v8
   126e8:	02fbda63          	bge	s7,a5,1271c <attention_bmm_rvv_f32+0x146>
   126ec:	9542                	add	a0,a0,a6
   126ee:	00650eb3          	add	t4,a0,t1
   126f2:	0e8a                	slli	t4,t4,0x2
   126f4:	9efe                	add	t4,t4,t6
   126f6:	020ee407          	vle32.v	v8,(t4)
   126fa:	0042a787          	flw	fa5,4(t0)
   126fe:	2889                	addiw	a7,a7,2
   12700:	b287d257          	vfmacc.vf	v4,fa5,v8
   12704:	00f8dc63          	bge	a7,a5,1271c <attention_bmm_rvv_f32+0x146>
   12708:	9542                	add	a0,a0,a6
   1270a:	951a                	add	a0,a0,t1
   1270c:	050a                	slli	a0,a0,0x2
   1270e:	957e                	add	a0,a0,t6
   12710:	02056407          	vle32.v	v8,(a0)
   12714:	0082a787          	flw	fa5,8(t0)
   12718:	b287d257          	vfmacc.vf	v4,fa5,v8
   1271c:	006c8533          	add	a0,s9,t1
   12720:	050a                	slli	a0,a0,0x2
   12722:	9522                	add	a0,a0,s0
   12724:	02056227          	vse32.v	v4,(a0)
   12728:	0066833b          	addw	t1,a3,t1
   1272c:	f3034fe3          	blt	t1,a6,1266a <attention_bmm_rvv_f32+0x94>
   12730:	68a2                	ld	a7,8(sp)
   12732:	9cc2                	add	s9,s9,a6
   12734:	9956                	add	s2,s2,s5
   12736:	2885                	addiw	a7,a7,1
   12738:	f31995e3          	bne	s3,a7,12662 <attention_bmm_rvv_f32+0x8c>
   1273c:	01ee08b3          	add	a7,t3,t5
   12740:	00138b9b          	addiw	s7,t2,1
   12744:	8e5a                	mv	t3,s6
   12746:	9fea                	add	t6,t6,s10
   12748:	8b6e                	mv	s6,s11
   1274a:	9c72                	add	s8,s8,t3
   1274c:	f17d94e3          	bne	s11,s7,12654 <attention_bmm_rvv_f32+0x7e>
   12750:	7426                	ld	s0,104(sp)
   12752:	7486                	ld	s1,96(sp)
   12754:	6966                	ld	s2,88(sp)
   12756:	6a26                	ld	s4,72(sp)
   12758:	6a86                	ld	s5,64(sp)
   1275a:	7bc2                	ld	s7,48(sp)
   1275c:	7c22                	ld	s8,40(sp)
   1275e:	7c82                	ld	s9,32(sp)
   12760:	6d62                	ld	s10,24(sp)
   12762:	6dc2                	ld	s11,16(sp)
   12764:	7b62                	ld	s6,56(sp)
   12766:	69c6                	ld	s3,80(sp)
   12768:	6165                	addi	sp,sp,112
   1276a:	8082                	ret
   1276c:	4881                	li	a7,0
   1276e:	bf91                	j	126c2 <attention_bmm_rvv_f32+0xec>
   12770:	69c6                	ld	s3,80(sp)
   12772:	873e                	mv	a4,a5
   12774:	6165                	addi	sp,sp,112
   12776:	b0b5                	j	11fe2 <(anonymous namespace)::whisper_pv_m1_n64_rvv_v3(float const*, float const*, float*, int, int)>
   12778:	69c6                	ld	s3,80(sp)
   1277a:	8742                	mv	a4,a6
   1277c:	6165                	addi	sp,sp,112
   1277e:	d48ff06f          	j	11cc6 <(anonymous namespace)::whisper_qk_m1_k64_rvv_v3(float const*, float const*, float*, int, int)>

0000000000012782 <attention_matmul>:
   12782:	6118                	ld	a4,0(a0)
   12784:	651c                	ld	a5,8(a0)
   12786:	46c1                	li	a3,16
   12788:	8f99                	sub	a5,a5,a4
   1278a:	08f6d063          	bge	a3,a5,1280a <attention_matmul+0x88>
   1278e:	6308                	ld	a0,0(a4)
   12790:	468d                	li	a3,3
   12792:	491c                	lw	a5,16(a0)
   12794:	00d79663          	bne	a5,a3,127a0 <attention_matmul+0x1e>
   12798:	670c                	ld	a1,8(a4)
   1279a:	4994                	lw	a3,16(a1)
   1279c:	00f68c63          	beq	a3,a5,127b4 <attention_matmul+0x32>
   127a0:	65cd                	lui	a1,0x13
   127a2:	6555                	lui	a0,0x15
   127a4:	c9058593          	addi	a1,a1,-880 # 12c90 <_IO_stdin_used+0x30>
   127a8:	0d050513          	addi	a0,a0,208 # 150d0 <std::cerr@GLIBCXX_3.4>
   127ac:	02900613          	li	a2,41
   127b0:	cf0fe06f          	j	10ca0 <std::basic_ostream<char, std::char_traits<char> >& std::__ostream_insert<char, std::char_traits<char> >(std::basic_ostream<char, std::char_traits<char> >&, char const*, long)@plt>
   127b4:	6b10                	ld	a2,16(a4)
   127b6:	4a1c                	lw	a5,16(a2)
   127b8:	fed794e3          	bne	a5,a3,127a0 <attention_matmul+0x1e>
   127bc:	01853803          	ld	a6,24(a0)
   127c0:	0185b883          	ld	a7,24(a1)
   127c4:	00082303          	lw	t1,0(a6)
   127c8:	0008a703          	lw	a4,0(a7)
   127cc:	01082783          	lw	a5,16(a6)
   127d0:	0088a683          	lw	a3,8(a7)
   127d4:	40670733          	sub	a4,a4,t1
   127d8:	8e9d                	sub	a3,a3,a5
   127da:	8f55                	or	a4,a4,a3
   127dc:	e329                	bnez	a4,1281e <attention_matmul+0x9c>
   127de:	01863e03          	ld	t3,24(a2)
   127e2:	000e2683          	lw	a3,0(t3)
   127e6:	02669c63          	bne	a3,t1,1281e <attention_matmul+0x9c>
   127ea:	00882803          	lw	a6,8(a6)
   127ee:	008e2703          	lw	a4,8(t3)
   127f2:	03071663          	bne	a4,a6,1281e <attention_matmul+0x9c>
   127f6:	0108a883          	lw	a7,16(a7)
   127fa:	010e2803          	lw	a6,16(t3)
   127fe:	03181063          	bne	a6,a7,1281e <attention_matmul+0x9c>
   12802:	6210                	ld	a2,0(a2)
   12804:	618c                	ld	a1,0(a1)
   12806:	6108                	ld	a0,0(a0)
   12808:	b3f9                	j	125d6 <attention_bmm_rvv_f32>
   1280a:	65cd                	lui	a1,0x13
   1280c:	6555                	lui	a0,0x15
   1280e:	c6858593          	addi	a1,a1,-920 # 12c68 <_IO_stdin_used+0x8>
   12812:	0d050513          	addi	a0,a0,208 # 150d0 <std::cerr@GLIBCXX_3.4>
   12816:	02400613          	li	a2,36
   1281a:	c86fe06f          	j	10ca0 <std::basic_ostream<char, std::char_traits<char> >& std::__ostream_insert<char, std::char_traits<char> >(std::basic_ostream<char, std::char_traits<char> >&, char const*, long)@plt>
   1281e:	65cd                	lui	a1,0x13
   12820:	6555                	lui	a0,0x15
   12822:	cc058593          	addi	a1,a1,-832 # 12cc0 <_IO_stdin_used+0x60>
   12826:	0d050513          	addi	a0,a0,208 # 150d0 <std::cerr@GLIBCXX_3.4>
   1282a:	02200613          	li	a2,34
   1282e:	c72fe06f          	j	10ca0 <std::basic_ostream<char, std::char_traits<char> >& std::__ostream_insert<char, std::char_traits<char> >(std::basic_ostream<char, std::char_traits<char> >&, char const*, long)@plt>

0000000000012832 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]>:
   12832:	fff60793          	addi	a5,a2,-1
   12836:	03f7d313          	srli	t1,a5,0x3f
   1283a:	933e                	add	t1,t1,a5
   1283c:	40135313          	srai	t1,t1,0x1
   12840:	00167e93          	andi	t4,a2,1
   12844:	0865d963          	bge	a1,t1,128d6 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0xa4>
   12848:	872e                	mv	a4,a1
   1284a:	a011                	j	1284e <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x1c>
   1284c:	8746                	mv	a4,a7
   1284e:	00170793          	addi	a5,a4,1
   12852:	00179893          	slli	a7,a5,0x1
   12856:	fff88813          	addi	a6,a7,-1
   1285a:	0792                	slli	a5,a5,0x4
   1285c:	00381693          	slli	a3,a6,0x3
   12860:	97aa                	add	a5,a5,a0
   12862:	96aa                	add	a3,a3,a0
   12864:	2298                	fld	fa4,0(a3)
   12866:	239c                	fld	fa5,0(a5)
   12868:	a2e79e53          	flt.d	t3,fa5,fa4
   1286c:	000e0663          	beqz	t3,12878 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x46>
   12870:	22e707d3          	fmv.d	fa5,fa4
   12874:	87b6                	mv	a5,a3
   12876:	88c2                	mv	a7,a6
   12878:	070e                	slli	a4,a4,0x3
   1287a:	972a                	add	a4,a4,a0
   1287c:	a31c                	fsd	fa5,0(a4)
   1287e:	fc68c7e3          	blt	a7,t1,1284c <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x1a>
   12882:	000e9663          	bnez	t4,1288e <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x5c>
   12886:	1679                	addi	a2,a2,-2
   12888:	8605                	srai	a2,a2,0x1
   1288a:	07160163          	beq	a2,a7,128ec <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0xba>
   1288e:	fff88693          	addi	a3,a7,-1
   12892:	03f6d713          	srli	a4,a3,0x3f
   12896:	9736                	add	a4,a4,a3
   12898:	8705                	srai	a4,a4,0x1
   1289a:	0115ca63          	blt	a1,a7,128ae <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x7c>
   1289e:	a03d                	j	128cc <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x9a>
   128a0:	a39c                	fsd	fa5,0(a5)
   128a2:	9642                	add	a2,a2,a6
   128a4:	88ba                	mv	a7,a4
   128a6:	02e5d563          	bge	a1,a4,128d0 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x9e>
   128aa:	40165713          	srai	a4,a2,0x1
   128ae:	00371693          	slli	a3,a4,0x3
   128b2:	96aa                	add	a3,a3,a0
   128b4:	229c                	fld	fa5,0(a3)
   128b6:	00389793          	slli	a5,a7,0x3
   128ba:	fff70813          	addi	a6,a4,-1
   128be:	a2a798d3          	flt.d	a7,fa5,fa0
   128c2:	03f85613          	srli	a2,a6,0x3f
   128c6:	97aa                	add	a5,a5,a0
   128c8:	fc089ce3          	bnez	a7,128a0 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x6e>
   128cc:	a388                	fsd	fa0,0(a5)
   128ce:	8082                	ret
   128d0:	87b6                	mv	a5,a3
   128d2:	a388                	fsd	fa0,0(a5)
   128d4:	8082                	ret
   128d6:	00359793          	slli	a5,a1,0x3
   128da:	97aa                	add	a5,a5,a0
   128dc:	fe0e98e3          	bnez	t4,128cc <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x9a>
   128e0:	ffe60713          	addi	a4,a2,-2
   128e4:	8705                	srai	a4,a4,0x1
   128e6:	fee593e3          	bne	a1,a4,128cc <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x9a>
   128ea:	88ae                	mv	a7,a1
   128ec:	00189613          	slli	a2,a7,0x1
   128f0:	0605                	addi	a2,a2,1
   128f2:	00361693          	slli	a3,a2,0x3
   128f6:	96aa                	add	a3,a3,a0
   128f8:	229c                	fld	fa5,0(a3)
   128fa:	8746                	mv	a4,a7
   128fc:	88b2                	mv	a7,a2
   128fe:	a39c                	fsd	fa5,0(a5)
   12900:	87b6                	mv	a5,a3
   12902:	bf61                	j	1289a <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]+0x68>

0000000000012904 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]>:
   12904:	08b50863          	beq	a0,a1,12994 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x90>
   12908:	7139                	addi	sp,sp,-64
   1290a:	f822                	sd	s0,48(sp)
   1290c:	fc06                	sd	ra,56(sp)
   1290e:	00850413          	addi	s0,a0,8
   12912:	04b40563          	beq	s0,a1,1295c <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x58>
   12916:	f426                	sd	s1,40(sp)
   12918:	44a1                	li	s1,8
   1291a:	f04a                	sd	s2,32(sp)
   1291c:	ec4e                	sd	s3,24(sp)
   1291e:	e852                	sd	s4,16(sp)
   12920:	a422                	fsd	fs0,8(sp)
   12922:	89ae                	mv	s3,a1
   12924:	892a                	mv	s2,a0
   12926:	8a26                	mv	s4,s1
   12928:	2000                	fld	fs0,0(s0)
   1292a:	00093787          	fld	fa5,0(s2)
   1292e:	a2f417d3          	flt.d	a5,fs0,fa5
   12932:	cb8d                	beqz	a5,12964 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x60>
   12934:	409a0533          	sub	a0,s4,s1
   12938:	9522                	add	a0,a0,s0
   1293a:	049a5663          	bge	s4,s1,12986 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x82>
   1293e:	8626                	mv	a2,s1
   12940:	85ca                	mv	a1,s2
   12942:	c1efe0ef          	jal	10d60 <memmove@plt>
   12946:	00893027          	fsd	fs0,0(s2)
   1294a:	0421                	addi	s0,s0,8
   1294c:	04a1                	addi	s1,s1,8
   1294e:	fd341de3          	bne	s0,s3,12928 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x24>
   12952:	74a2                	ld	s1,40(sp)
   12954:	7902                	ld	s2,32(sp)
   12956:	69e2                	ld	s3,24(sp)
   12958:	6a42                	ld	s4,16(sp)
   1295a:	2422                	fld	fs0,8(sp)
   1295c:	70e2                	ld	ra,56(sp)
   1295e:	7442                	ld	s0,48(sp)
   12960:	6121                	addi	sp,sp,64
   12962:	8082                	ret
   12964:	ff843787          	fld	fa5,-8(s0)
   12968:	ff840793          	addi	a5,s0,-8
   1296c:	a2f41753          	flt.d	a4,fs0,fa5
   12970:	cf19                	beqz	a4,1298e <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x8a>
   12972:	a79c                	fsd	fa5,8(a5)
   12974:	873e                	mv	a4,a5
   12976:	ff87b787          	fld	fa5,-8(a5)
   1297a:	17e1                	addi	a5,a5,-8
   1297c:	a2f416d3          	flt.d	a3,fs0,fa5
   12980:	faed                	bnez	a3,12972 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x6e>
   12982:	a300                	fsd	fs0,0(a4)
   12984:	b7d9                	j	1294a <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x46>
   12986:	fd4490e3          	bne	s1,s4,12946 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x42>
   1298a:	a11c                	fsd	fa5,0(a0)
   1298c:	bf6d                	j	12946 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x42>
   1298e:	8722                	mv	a4,s0
   12990:	a300                	fsd	fs0,0(a4)
   12992:	bf65                	j	1294a <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x46>
   12994:	8082                	ret

0000000000012996 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]>:
   12996:	7139                	addi	sp,sp,-64
   12998:	f426                	sd	s1,40(sp)
   1299a:	fc06                	sd	ra,56(sp)
   1299c:	40a587b3          	sub	a5,a1,a0
   129a0:	08000493          	li	s1,128
   129a4:	10f4d963          	bge	s1,a5,12ab6 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x120>
   129a8:	f822                	sd	s0,48(sp)
   129aa:	f04a                	sd	s2,32(sp)
   129ac:	ec4e                	sd	s3,24(sp)
   129ae:	e852                	sd	s4,16(sp)
   129b0:	89b2                	mv	s3,a2
   129b2:	4037da13          	srai	s4,a5,0x3
   129b6:	892e                	mv	s2,a1
   129b8:	842a                	mv	s0,a0
   129ba:	8791                	srai	a5,a5,0x4
   129bc:	0a098163          	beqz	s3,12a5e <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0xc8>
   129c0:	078e                	slli	a5,a5,0x3
   129c2:	97a2                	add	a5,a5,s0
   129c4:	2394                	fld	fa3,0(a5)
   129c6:	241c                	fld	fa5,8(s0)
   129c8:	ff893607          	fld	fa2,-8(s2)
   129cc:	2018                	fld	fa4,0(s0)
   129ce:	a2d79753          	flt.d	a4,fa5,fa3
   129d2:	19fd                	addi	s3,s3,-1
   129d4:	00840513          	addi	a0,s0,8
   129d8:	c37d                	beqz	a4,12abe <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x128>
   129da:	a2c69753          	flt.d	a4,fa3,fa2
   129de:	e775                	bnez	a4,12aca <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x134>
   129e0:	a2c797d3          	flt.d	a5,fa5,fa2
   129e4:	c7b9                	beqz	a5,12a32 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x9c>
   129e6:	a010                	fsd	fa2,0(s0)
   129e8:	fee93c27          	fsd	fa4,-8(s2)
   129ec:	2418                	fld	fa4,8(s0)
   129ee:	201c                	fld	fa5,0(s0)
   129f0:	874a                	mv	a4,s2
   129f2:	a2f716d3          	flt.d	a3,fa4,fa5
   129f6:	00850793          	addi	a5,a0,8
   129fa:	c699                	beqz	a3,12a08 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x72>
   129fc:	853e                	mv	a0,a5
   129fe:	2398                	fld	fa4,0(a5)
   12a00:	07a1                	addi	a5,a5,8
   12a02:	a2f716d3          	flt.d	a3,fa4,fa5
   12a06:	fafd                	bnez	a3,129fc <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x66>
   12a08:	ff873687          	fld	fa3,-8(a4)
   12a0c:	ff070793          	addi	a5,a4,-16
   12a10:	a2d796d3          	flt.d	a3,fa5,fa3
   12a14:	c295                	beqz	a3,12a38 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0xa2>
   12a16:	873e                	mv	a4,a5
   12a18:	2394                	fld	fa3,0(a5)
   12a1a:	17e1                	addi	a5,a5,-8
   12a1c:	a2d796d3          	flt.d	a3,fa5,fa3
   12a20:	fafd                	bnez	a3,12a16 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x80>
   12a22:	00e57e63          	bgeu	a0,a4,12a3e <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0xa8>
   12a26:	a114                	fsd	fa3,0(a0)
   12a28:	a318                	fsd	fa4,0(a4)
   12a2a:	2518                	fld	fa4,8(a0)
   12a2c:	201c                	fld	fa5,0(s0)
   12a2e:	0521                	addi	a0,a0,8
   12a30:	b7c9                	j	129f2 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x5c>
   12a32:	a01c                	fsd	fa5,0(s0)
   12a34:	a418                	fsd	fa4,8(s0)
   12a36:	bf6d                	j	129f0 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x5a>
   12a38:	1761                	addi	a4,a4,-8
   12a3a:	fee566e3          	bltu	a0,a4,12a26 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x90>
   12a3e:	85ca                	mv	a1,s2
   12a40:	864e                	mv	a2,s3
   12a42:	e42a                	sd	a0,8(sp)
   12a44:	f53ff0ef          	jal	12996 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]>
   12a48:	6522                	ld	a0,8(sp)
   12a4a:	408507b3          	sub	a5,a0,s0
   12a4e:	06f4d063          	bge	s1,a5,12aae <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x118>
   12a52:	4037da13          	srai	s4,a5,0x3
   12a56:	892a                	mv	s2,a0
   12a58:	8791                	srai	a5,a5,0x4
   12a5a:	f60993e3          	bnez	s3,129c0 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x2a>
   12a5e:	00379993          	slli	s3,a5,0x3
   12a62:	99a2                	add	s3,s3,s0
   12a64:	fff78493          	addi	s1,a5,-1
   12a68:	a019                	j	12a6e <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0xd8>
   12a6a:	19e1                	addi	s3,s3,-8
   12a6c:	14fd                	addi	s1,s1,-1
   12a6e:	ff89b507          	fld	fa0,-8(s3)
   12a72:	8652                	mv	a2,s4
   12a74:	85a6                	mv	a1,s1
   12a76:	8522                	mv	a0,s0
   12a78:	dbbff0ef          	jal	12832 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]>
   12a7c:	f4fd                	bnez	s1,12a6a <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0xd4>
   12a7e:	408907b3          	sub	a5,s2,s0
   12a82:	49a1                	li	s3,8
   12a84:	02f9d563          	bge	s3,a5,12aae <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x118>
   12a88:	ff878493          	addi	s1,a5,-8
   12a8c:	1961                	addi	s2,s2,-8
   12a8e:	201c                	fld	fa5,0(s0)
   12a90:	00093507          	fld	fa0,0(s2)
   12a94:	4034d613          	srai	a2,s1,0x3
   12a98:	00f93027          	fsd	fa5,0(s2)
   12a9c:	4581                	li	a1,0
   12a9e:	8522                	mv	a0,s0
   12aa0:	8a26                	mv	s4,s1
   12aa2:	d91ff0ef          	jal	12832 <void std::__adjust_heap<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, double, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, long, double, std::less<void>) [clone .isra.0]>
   12aa6:	1961                	addi	s2,s2,-8
   12aa8:	14e1                	addi	s1,s1,-8
   12aaa:	ff49c2e3          	blt	s3,s4,12a8e <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0xf8>
   12aae:	7442                	ld	s0,48(sp)
   12ab0:	7902                	ld	s2,32(sp)
   12ab2:	69e2                	ld	s3,24(sp)
   12ab4:	6a42                	ld	s4,16(sp)
   12ab6:	70e2                	ld	ra,56(sp)
   12ab8:	74a2                	ld	s1,40(sp)
   12aba:	6121                	addi	sp,sp,64
   12abc:	8082                	ret
   12abe:	a2c79753          	flt.d	a4,fa5,fa2
   12ac2:	fb25                	bnez	a4,12a32 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x9c>
   12ac4:	a2c69753          	flt.d	a4,fa3,fa2
   12ac8:	ff19                	bnez	a4,129e6 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x50>
   12aca:	a014                	fsd	fa3,0(s0)
   12acc:	a398                	fsd	fa4,0(a5)
   12ace:	2418                	fld	fa4,8(s0)
   12ad0:	201c                	fld	fa5,0(s0)
   12ad2:	bf39                	j	129f0 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]+0x5a>

0000000000012ad4 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]>:
   12ad4:	08b50c63          	beq	a0,a1,12b6c <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x98>
   12ad8:	1101                	addi	sp,sp,-32
   12ada:	e04a                	sd	s2,0(sp)
   12adc:	40a58933          	sub	s2,a1,a0
   12ae0:	e822                	sd	s0,16(sp)
   12ae2:	e426                	sd	s1,8(sp)
   12ae4:	ec06                	sd	ra,24(sp)
   12ae6:	84aa                	mv	s1,a0
   12ae8:	40395513          	srai	a0,s2,0x3
   12aec:	842e                	mv	s0,a1
   12aee:	04000793          	li	a5,64
   12af2:	c501                	beqz	a0,12afa <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x26>
   12af4:	9bcfe0ef          	jal	10cb0 <__clzdi2@plt>
   12af8:	87aa                	mv	a5,a0
   12afa:	03f00613          	li	a2,63
   12afe:	9e1d                	subw	a2,a2,a5
   12b00:	0606                	slli	a2,a2,0x1
   12b02:	85a2                	mv	a1,s0
   12b04:	8526                	mv	a0,s1
   12b06:	e91ff0ef          	jal	12996 <void std::__introsort_loop<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, long, std::less<void>) [clone .isra.0]>
   12b0a:	08000793          	li	a5,128
   12b0e:	0527d563          	bge	a5,s2,12b58 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x84>
   12b12:	00f48933          	add	s2,s1,a5
   12b16:	8526                	mv	a0,s1
   12b18:	85ca                	mv	a1,s2
   12b1a:	debff0ef          	jal	12904 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]>
   12b1e:	02890763          	beq	s2,s0,12b4c <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x78>
   12b22:	00093707          	fld	fa4,0(s2)
   12b26:	ff893787          	fld	fa5,-8(s2)
   12b2a:	ff890793          	addi	a5,s2,-8
   12b2e:	a2f71753          	flt.d	a4,fa4,fa5
   12b32:	cb1d                	beqz	a4,12b68 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x94>
   12b34:	a79c                	fsd	fa5,8(a5)
   12b36:	873e                	mv	a4,a5
   12b38:	ff87b787          	fld	fa5,-8(a5)
   12b3c:	17e1                	addi	a5,a5,-8
   12b3e:	a2f716d3          	flt.d	a3,fa4,fa5
   12b42:	faed                	bnez	a3,12b34 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x60>
   12b44:	a318                	fsd	fa4,0(a4)
   12b46:	0921                	addi	s2,s2,8
   12b48:	fc891de3          	bne	s2,s0,12b22 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x4e>
   12b4c:	60e2                	ld	ra,24(sp)
   12b4e:	6442                	ld	s0,16(sp)
   12b50:	64a2                	ld	s1,8(sp)
   12b52:	6902                	ld	s2,0(sp)
   12b54:	6105                	addi	sp,sp,32
   12b56:	8082                	ret
   12b58:	85a2                	mv	a1,s0
   12b5a:	6442                	ld	s0,16(sp)
   12b5c:	60e2                	ld	ra,24(sp)
   12b5e:	6902                	ld	s2,0(sp)
   12b60:	8526                	mv	a0,s1
   12b62:	64a2                	ld	s1,8(sp)
   12b64:	6105                	addi	sp,sp,32
   12b66:	bb79                	j	12904 <void std::__insertion_sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]>
   12b68:	874a                	mv	a4,s2
   12b6a:	bfe9                	j	12b44 <void std::__sort<__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void> >(__gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, __gnu_cxx::__normal_iterator<double*, std::vector<double, std::allocator<double> > >, std::less<void>) [clone .isra.0]+0x70>
   12b6c:	8082                	ret

0000000000012b6e <bool std::operator==<char, std::char_traits<char>, std::allocator<char> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)>:
   12b6e:	6510                	ld	a2,8(a0)
   12b70:	87ae                	mv	a5,a1
   12b72:	4701                	li	a4,0
   12b74:	0c0076d7          	vsetvli	a3,zero,e8,m1,ta,ma
   12b78:	97ba                	add	a5,a5,a4
   12b7a:	03078087          	vle8ff.v	v1,(a5)
   12b7e:	621030d7          	vmseq.vi	v1,v1,0
   12b82:	c2002773          	csrr	a4,vl
   12b86:	4218a857          	vfirst.m	a6,v1
   12b8a:	fe0845e3          	bltz	a6,12b74 <bool std::operator==<char, std::char_traits<char>, std::allocator<char> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)+0x6>
   12b8e:	97c2                	add	a5,a5,a6
   12b90:	8f8d                	sub	a5,a5,a1
   12b92:	4701                	li	a4,0
   12b94:	00f60463          	beq	a2,a5,12b9c <bool std::operator==<char, std::char_traits<char>, std::allocator<char> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)+0x2e>
   12b98:	853a                	mv	a0,a4
   12b9a:	8082                	ret
   12b9c:	4705                	li	a4,1
   12b9e:	de6d                	beqz	a2,12b98 <bool std::operator==<char, std::char_traits<char>, std::allocator<char> >(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)+0x2a>
   12ba0:	6108                	ld	a0,0(a0)
   12ba2:	1141                	addi	sp,sp,-16
   12ba4:	e406                	sd	ra,8(sp)
   12ba6:	92afe0ef          	jal	10cd0 <memcmp@plt>
   12baa:	60a2                	ld	ra,8(sp)
   12bac:	00153713          	seqz	a4,a0
   12bb0:	853a                	mv	a0,a4
   12bb2:	0141                	addi	sp,sp,16
   12bb4:	8082                	ret

0000000000012bb6 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)>:
   12bb6:	7139                	addi	sp,sp,-64
   12bb8:	f822                	sd	s0,48(sp)
   12bba:	ec4e                	sd	s3,24(sp)
   12bbc:	6500                	ld	s0,8(a0)
   12bbe:	00053983          	ld	s3,0(a0)
   12bc2:	577d                	li	a4,-1
   12bc4:	fc06                	sd	ra,56(sp)
   12bc6:	41340433          	sub	s0,s0,s3
   12bca:	f426                	sd	s1,40(sp)
   12bcc:	f04a                	sd	s2,32(sp)
   12bce:	8311                	srli	a4,a4,0x4
   12bd0:	40345793          	srai	a5,s0,0x3
   12bd4:	08e78063          	beq	a5,a4,12c54 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x9e>
   12bd8:	84aa                	mv	s1,a0
   12bda:	853e                	mv	a0,a5
   12bdc:	e391                	bnez	a5,12be0 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x2a>
   12bde:	4505                	li	a0,1
   12be0:	577d                	li	a4,-1
   12be2:	953e                	add	a0,a0,a5
   12be4:	00475793          	srli	a5,a4,0x4
   12be8:	00a7f363          	bgeu	a5,a0,12bee <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x38>
   12bec:	853e                	mv	a0,a5
   12bee:	00351913          	slli	s2,a0,0x3
   12bf2:	854a                	mv	a0,s2
   12bf4:	e42e                	sd	a1,8(sp)
   12bf6:	88afe0ef          	jal	10c80 <operator new(unsigned long)@plt>
   12bfa:	65a2                	ld	a1,8(sp)
   12bfc:	00850733          	add	a4,a0,s0
   12c00:	87aa                	mv	a5,a0
   12c02:	219c                	fld	fa5,0(a1)
   12c04:	a31c                	fsd	fa5,0(a4)
   12c06:	e80d                	bnez	s0,12c38 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x82>
   12c08:	0421                	addi	s0,s0,8
   12c0a:	943e                	add	s0,s0,a5
   12c0c:	00098a63          	beqz	s3,12c20 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x6a>
   12c10:	688c                	ld	a1,16(s1)
   12c12:	854e                	mv	a0,s3
   12c14:	e43e                	sd	a5,8(sp)
   12c16:	413585b3          	sub	a1,a1,s3
   12c1a:	876fe0ef          	jal	10c90 <operator delete(void*, unsigned long)@plt>
   12c1e:	67a2                	ld	a5,8(sp)
   12c20:	e480                	sd	s0,8(s1)
   12c22:	70e2                	ld	ra,56(sp)
   12c24:	7442                	ld	s0,48(sp)
   12c26:	01278533          	add	a0,a5,s2
   12c2a:	e888                	sd	a0,16(s1)
   12c2c:	e09c                	sd	a5,0(s1)
   12c2e:	7902                	ld	s2,32(sp)
   12c30:	74a2                	ld	s1,40(sp)
   12c32:	69e2                	ld	s3,24(sp)
   12c34:	6121                	addi	sp,sp,64
   12c36:	8082                	ret
   12c38:	862a                	mv	a2,a0
   12c3a:	85ce                	mv	a1,s3
   12c3c:	86a2                	mv	a3,s0
   12c3e:	0c06f757          	vsetvli	a4,a3,e8,m1,ta,ma
   12c42:	02058087          	vle8.v	v1,(a1)
   12c46:	8e99                	sub	a3,a3,a4
   12c48:	95ba                	add	a1,a1,a4
   12c4a:	020600a7          	vse8.v	v1,(a2)
   12c4e:	963a                	add	a2,a2,a4
   12c50:	f6fd                	bnez	a3,12c3e <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x88>
   12c52:	bf5d                	j	12c08 <void std::vector<double, std::allocator<double> >::_M_realloc_append<double>(double&&)+0x52>
   12c54:	654d                	lui	a0,0x13
   12c56:	ce850513          	addi	a0,a0,-792 # 12ce8 <_IO_stdin_used+0x88>
   12c5a:	806fe0ef          	jal	10c60 <std::__throw_length_error(char const*)@plt>

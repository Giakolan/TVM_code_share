#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-$HOME/tvm-byoc-kiwipedia-RVV/rvv_attention}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$TARGET/backup_before_rvv_compare_$STAMP"

if [[ ! -d "$TARGET" ]]; then
  echo "Target rvv_attention directory not found: $TARGET"
  exit 1
fi

mkdir -p "$BACKUP/benchmark" "$BACKUP/scripts" "$BACKUP/kernels"

backup_if_exists() {
  local rel="$1"
  if [[ -f "$TARGET/$rel" ]]; then
    cp -a "$TARGET/$rel" "$BACKUP/$rel"
  fi
}

backup_if_exists "benchmark/benchmark_attention_rvv.cpp"
backup_if_exists "scripts/build_qemu_benchmark.sh"
backup_if_exists "scripts/run_qemu_benchmark.sh"
backup_if_exists "scripts/env_rvv_project.sh"
backup_if_exists "kernels/libattention_matmul_rvv_baseline.cpp"

install -m 0644 "$PATCH_DIR/kernels/libattention_matmul_rvv_baseline.cpp" \
  "$TARGET/kernels/libattention_matmul_rvv_baseline.cpp"
install -m 0644 "$PATCH_DIR/benchmark/benchmark_attention_rvv.cpp" \
  "$TARGET/benchmark/benchmark_attention_rvv.cpp"
install -m 0755 "$PATCH_DIR/scripts/build_qemu_benchmark.sh" \
  "$TARGET/scripts/build_qemu_benchmark.sh"
install -m 0755 "$PATCH_DIR/scripts/run_qemu_benchmark.sh" \
  "$TARGET/scripts/run_qemu_benchmark.sh"
install -m 0755 "$PATCH_DIR/scripts/env_rvv_project.sh" \
  "$TARGET/scripts/env_rvv_project.sh"

echo "Installed RVV baseline-vs-v2 comparison patch."
echo "Backup: $BACKUP"
echo
echo "Current v2 kernel is NOT overwritten:"
echo "  $TARGET/kernels/libattention_matmul_rvv.cpp"
echo
echo "Next:"
echo "  cd $TARGET"
echo "  source scripts/env_rvv_project.sh"
echo "  rm -rf build-riscv"
echo "  ./scripts/build_qemu_benchmark.sh"
echo "  ./scripts/run_qemu_benchmark.sh"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

// Original RVV MatMul baseline.
extern "C" void attention_bmm_rvv_baseline_f32(
    const float*, const float*, float*, int, int, int, int);

// Current optimized kernel.
// kernels/libattention_matmul_rvv.cpp must export this symbol.
extern "C" void attention_bmm_rvv_f32(
    const float*, const float*, float*, int, int, int, int);

namespace {

using Clock = std::chrono::steady_clock;

template <typename Fn>
double MedianUs(Fn&& fn, int warmup, int repeat) {
  for (int i = 0; i < warmup; ++i) fn();

  std::vector<double> samples;
  samples.reserve(repeat);
  for (int i = 0; i < repeat; ++i) {
    const auto t0 = Clock::now();
    fn();
    const auto t1 = Clock::now();
    samples.push_back(
        std::chrono::duration<double, std::micro>(t1 - t0).count());
  }

  std::sort(samples.begin(), samples.end());
  return samples[samples.size() / 2];
}

float MaxAbsError(const std::vector<float>& a, const std::vector<float>& b) {
  float e = 0.0f;
  for (size_t i = 0; i < a.size(); ++i) {
    e = std::max(e, std::fabs(a[i] - b[i]));
  }
  return e;
}

double Checksum(const std::vector<float>& v) {
  double s = 0.0;
  for (float x : v) s += static_cast<double>(x);
  return s;
}

void Usage(const char* argv0) {
  std::fprintf(
      stderr,
      "Usage: %s --mode qk|pv --kv N [--warmup N] [--repeat N] "
      "[--tol X] [--csv]\n"
      "  QK shape: A=[6,1,64], B=[6,64,kv], C=[6,1,kv]\n"
      "  PV shape: A=[6,1,kv], B=[6,kv,64], C=[6,1,64]\n"
      "  speedup = original_rvv_median_us / v2_median_us\n",
      argv0);
}

}  // namespace

int main(int argc, char** argv) {
  std::string mode;
  int kv = -1;
  int warmup = 10;
  int repeat = 100;
  float tolerance = 1e-4f;
  bool csv = false;

  for (int i = 1; i < argc; ++i) {
    if (std::strcmp(argv[i], "--mode") == 0 && i + 1 < argc) {
      mode = argv[++i];
    } else if (std::strcmp(argv[i], "--kv") == 0 && i + 1 < argc) {
      kv = std::atoi(argv[++i]);
    } else if (std::strcmp(argv[i], "--warmup") == 0 && i + 1 < argc) {
      warmup = std::atoi(argv[++i]);
    } else if (std::strcmp(argv[i], "--repeat") == 0 && i + 1 < argc) {
      repeat = std::atoi(argv[++i]);
    } else if (std::strcmp(argv[i], "--tol") == 0 && i + 1 < argc) {
      tolerance = std::strtof(argv[++i], nullptr);
    } else if (std::strcmp(argv[i], "--csv") == 0) {
      csv = true;
    } else {
      Usage(argv[0]);
      return 2;
    }
  }

  if ((mode != "qk" && mode != "pv") ||
      kv <= 0 || warmup < 0 || repeat <= 0 || tolerance < 0.0f) {
    Usage(argv[0]);
    return 2;
  }

  const int BH = 6;
  const int M = 1;
  const int K = (mode == "qk") ? 64 : kv;
  const int N = (mode == "qk") ? kv : 64;

  const size_t a_count = static_cast<size_t>(BH) * M * K;
  const size_t b_count = static_cast<size_t>(BH) * K * N;
  const size_t c_count = static_cast<size_t>(BH) * M * N;

  std::vector<float> A(a_count);
  std::vector<float> B(b_count);
  std::vector<float> Cbaseline(c_count);
  std::vector<float> Cv2(c_count);

  std::mt19937 rng(12345);
  std::uniform_real_distribution<float> dist(-0.25f, 0.25f);
  for (float& x : A) x = dist(rng);
  for (float& x : B) x = dist(rng);

  // Correctness check before timing.
  attention_bmm_rvv_baseline_f32(
      A.data(), B.data(), Cbaseline.data(), BH, M, K, N);
  attention_bmm_rvv_f32(
      A.data(), B.data(), Cv2.data(), BH, M, K, N);

  const float max_abs = MaxAbsError(Cbaseline, Cv2);
  if (max_abs > tolerance) {
    std::fprintf(
        stderr,
        "[FAIL] correctness mode=%s kv=%d max_abs_error=%g tolerance=%g\n",
        mode.c_str(), kv, max_abs, tolerance);
    return 3;
  }

  const double baseline_us = MedianUs([&]() {
    attention_bmm_rvv_baseline_f32(
        A.data(), B.data(), Cbaseline.data(), BH, M, K, N);
  }, warmup, repeat);

  const double v2_us = MedianUs([&]() {
    attention_bmm_rvv_f32(
        A.data(), B.data(), Cv2.data(), BH, M, K, N);
  }, warmup, repeat);

  const double speedup = baseline_us / v2_us;
  const double checksum = Checksum(Cv2);

  if (csv) {
    std::printf(
        "%s,%d,%d,%d,%d,%.6f,%.6f,%.6f,%.9g,%.9f\n",
        mode.c_str(), kv, K, N, repeat,
        baseline_us, v2_us, speedup, max_abs, checksum);
  } else {
    std::printf(
        "[ATTENTION_RVV_QEMU] mode=%s kv=%d BH=%d M=%d K=%d N=%d "
        "warmup=%d repeat=%d original_rvv_median_us=%.3f "
        "v2_median_us=%.3f speedup=%.3fx "
        "max_abs_error=%g checksum=%.6f\n",
        mode.c_str(), kv, BH, M, K, N, warmup, repeat,
        baseline_us, v2_us, speedup, max_abs, checksum);
  }

  return 0;
}

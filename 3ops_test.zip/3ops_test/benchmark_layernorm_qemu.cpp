#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <random>
#include <vector>

extern "C" int whisper_layernorm_f32(const float* x, const float* gamma,
                                      const float* beta, float* y,
                                      int64_t rows, int64_t hidden, float epsilon);

static double checksum(const std::vector<float>& v) {
    double s = 0.0;
    for (float x : v) s += x;
    return s;
}

int main(int argc, char** argv) {
    int64_t rows   = (argc > 1) ? std::atoll(argv[1]) : 1500;
    int64_t hidden = (argc > 2) ? std::atoll(argv[2]) : 384;
    int warmup     = (argc > 3) ? std::atoi(argv[3]) : 2;
    int repeat     = (argc > 4) ? std::atoi(argv[4]) : 10;
    float eps      = (argc > 5) ? std::strtof(argv[5], nullptr) : 1e-5f;

    if (rows <= 0 || hidden <= 0 || warmup < 0 || repeat <= 0 || !(eps > 0.0f)) {
        std::cerr << "Usage: " << argv[0]
                  << " [rows] [hidden] [warmup] [repeat] [epsilon]\n";
        return 1;
    }

    if (rows > INT64_MAX / hidden) {
        std::cerr << "shape overflow\n";
        return 1;
    }

    const int64_t count = rows * hidden;
    std::vector<float> x((size_t)count), y((size_t)count);
    std::vector<float> gamma((size_t)hidden), beta((size_t)hidden);

    std::mt19937 rng(12345);
    std::normal_distribution<float> xdist(0.0f, 1.0f);
    std::uniform_real_distribution<float> gdist(0.8f, 1.2f);
    std::uniform_real_distribution<float> bdist(-0.1f, 0.1f);
    for (auto& v : x) v = xdist(rng);
    for (auto& v : gamma) v = gdist(rng);
    for (auto& v : beta) v = bdist(rng);

    for (int i = 0; i < warmup; ++i) {
        int rc = whisper_layernorm_f32(x.data(), gamma.data(), beta.data(),
                                       y.data(), rows, hidden, eps);
        if (rc != 0) {
            std::cerr << "warmup failed, rc=" << rc << "\n";
            return 2;
        }
    }

    std::vector<double> us;
    us.reserve((size_t)repeat);
    for (int i = 0; i < repeat; ++i) {
        auto t0 = std::chrono::steady_clock::now();
        int rc = whisper_layernorm_f32(x.data(), gamma.data(), beta.data(),
                                       y.data(), rows, hidden, eps);
        auto t1 = std::chrono::steady_clock::now();
        if (rc != 0) {
            std::cerr << "whisper_layernorm_f32 failed, rc=" << rc << "\n";
            return 2;
        }
        us.push_back(std::chrono::duration<double, std::micro>(t1 - t0).count());
    }

    bool finite = true;
    for (float v : y) {
        if (!std::isfinite(v)) {
            finite = false;
            break;
        }
    }

    std::sort(us.begin(), us.end());
    double total = 0.0;
    for (double t : us) total += t;
    double avg = total / repeat;
    double median = us[us.size() / 2];
    double min_us = us.front();
    double throughput = (double)count / (avg * 1e-6) / 1e6;

    std::cout << std::fixed << std::setprecision(3);
    std::cout << "=== LayerNorm QEMU benchmark ===\n";
    std::cout << "shape        : [" << rows << ", " << hidden << "]\n";
    std::cout << "epsilon      : " << eps << "\n";
    std::cout << "warmup       : " << warmup << "\n";
    std::cout << "repeat       : " << repeat << "\n";
    std::cout << "min          : " << min_us << " us\n";
    std::cout << "median       : " << median << " us\n";
    std::cout << "average      : " << avg << " us\n";
    std::cout << "throughput   : " << throughput << " M elements/s\n";
    std::cout << "checksum     : " << checksum(y) << "\n";
    std::cout << "finite check : " << (finite ? "PASS" : "FAIL") << "\n";
    return finite ? 0 : 3;
}

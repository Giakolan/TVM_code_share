#include "common.h"
extern "C" int whisper_has_rvv(void) { return W_RVV; }

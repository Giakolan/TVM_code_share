#include "whisper_dlpack.h"
#include "whisper_rvv_ops.h"
#include <stdint.h>
#include <stddef.h>
struct View { float* data; int64_t count; };
static int view(const DLTensor* t,View* v) {
    if(!t||t->ndim<1||!t->shape)return -1;
    if(t->device.device_type!=kDLCPU||t->dtype.code!=kDLFloat||t->dtype.bits!=32||t->dtype.lanes!=1)return -2;
    int64_t elements=1;
    for(int i=t->ndim-1;i>=0;--i){
        int64_t d=t->shape[i];if(d<0)return -1;
        // 長度一的維度，其 stride 不影響位址；其他維度必須 row-major。
        if(t->strides&&d>1&&t->strides[i]!=elements)return -2;
        if(d && elements>PTRDIFF_MAX/(int64_t)sizeof(float)/d)return -1;
        elements*=d;
    }
    if(elements && !t->data)return -1;
    uintptr_t base=(uintptr_t)t->data;
    if(t->byte_offset>UINTPTR_MAX-base)return -1;
    uintptr_t addr=base+(uintptr_t)t->byte_offset;
    if(addr%alignof(float))return -2;
    if((uint64_t)elements>(UINTPTR_MAX-addr)/sizeof(float))return -1;
    v->data=(float*)addr;v->count=elements;return 0;
}
static bool same_shape(const DLTensor* a,const DLTensor* b) {
    if(a->ndim!=b->ndim)return false;
    for(int i=0;i<a->ndim;++i)if(a->shape[i]!=b->shape[i])return false;
    return true;
}
extern "C" int whisper_softmax_dlpack(const DLTensor* x,DLTensor* y) {
    View a,b;int rc=view(x,&a);if(rc)return rc;rc=view(y,&b);if(rc)return rc;
    if(!same_shape(x,y))return -1;
    int64_t cols=x->shape[x->ndim-1];if(cols<=0)return -1;
    return whisper_softmax_f32(a.data,b.data,a.count/cols,cols);
}
extern "C" int whisper_layernorm_dlpack(const DLTensor* x,const DLTensor* gamma,
                                         const DLTensor* beta,DLTensor* y,float epsilon) {
    View a,g,b,o;int rc=view(x,&a);if(rc)return rc;rc=view(gamma,&g);if(rc)return rc;
    rc=view(beta,&b);if(rc)return rc;rc=view(y,&o);if(rc)return rc;
    int64_t h=x->shape[x->ndim-1];
    if(h<=0||!same_shape(x,y)||gamma->ndim!=1||beta->ndim!=1||g.count!=h||b.count!=h)return -1;
    return whisper_layernorm_f32(a.data,g.data,b.data,o.data,a.count/h,h,epsilon);
}
extern "C" int whisper_gelu_dlpack(const DLTensor* x,DLTensor* y) {
    View a,b;int rc=view(x,&a);if(rc)return rc;rc=view(y,&b);if(rc)return rc;
    if(!same_shape(x,y))return -1;
    return whisper_gelu_f32(a.data,b.data,a.count);
}

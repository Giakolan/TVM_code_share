#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <random>
#include <vector>

extern "C" int whisper_encoder_softmax_f32(const float* x, float* y,
                                            int64_t batch, int64_t heads,
                                            int64_t query_len, int64_t key_len);

int main(int argc, char** argv) {
    int64_t batch = (argc > 1) ? std::atoll(argv[1]) : 1;
    int64_t heads = (argc > 2) ? std::atoll(argv[2]) : 6;
    int64_t qlen  = (argc > 3) ? std::atoll(argv[3]) : 1500;
    int64_t klen  = (argc > 4) ? std::atoll(argv[4]) : 1500;
    int warmup    = (argc > 5) ? std::atoi(argv[5]) : 1;
    int repeat    = (argc > 6) ? std::atoi(argv[6]) : 3;

    if (batch <= 0 || heads <= 0 || qlen <= 0 || klen <= 0 ||
        warmup < 0 || repeat <= 0) {
        std::cerr << "Usage: " << argv[0]
                  << " [batch] [heads] [query_len] [key_len] [warmup] [repeat]\n";
        return 1;
    }

    if (batch > INT64_MAX / heads ||
        batch * heads > INT64_MAX / qlen ||
        batch * heads * qlen > INT64_MAX / klen) {
        std::cerr << "shape overflow\n";
        return 1;
    }

    const int64_t rows = batch * heads * qlen;
    const int64_t count = rows * klen;

    std::vector<float> x((size_t)count), y((size_t)count);
    std::mt19937 rng(12345);
    std::uniform_real_distribution<float> dist(-6.0f, 2.0f);
    for (auto& v : x) v = dist(rng);

    for (int i = 0; i < warmup; ++i) {
        int rc = whisper_encoder_softmax_f32(x.data(), y.data(),
                                             batch, heads, qlen, klen);
        if (rc != 0) {
            std::cerr << "warmup failed, rc=" << rc << "\n";
            return 2;
        }
    }

    std::vector<double> us;
    us.reserve((size_t)repeat);
    for (int i = 0; i < repeat; ++i) {
        auto t0 = std::chrono::steady_clock::now();
        int rc = whisper_encoder_softmax_f32(x.data(), y.data(),
                                             batch, heads, qlen, klen);
        auto t1 = std::chrono::steady_clock::now();
        if (rc != 0) {
            std::cerr << "whisper_encoder_softmax_f32 failed, rc=" << rc << "\n";
            return 2;
        }
        us.push_back(std::chrono::duration<double, std::micro>(t1 - t0).count());
    }

    double max_row_sum_error = 0.0;
    double checksum = 0.0;
    bool valid = true;
    for (int64_t r = 0; r < rows; ++r) {
        double row_sum = 0.0;
        const float* row = y.data() + r * klen;
        for (int64_t j = 0; j < klen; ++j) {
            float v = row[j];
            if (!std::isfinite(v) || v < 0.0f) valid = false;
            row_sum += v;
        }
        checksum += row_sum;
        max_row_sum_error = std::max(max_row_sum_error, std::abs(row_sum - 1.0));
    }
    valid = valid && (max_row_sum_error < 1e-3);

    std::sort(us.begin(), us.end());
    double total = 0.0;
    for (double t : us) total += t;
    double avg = total / repeat;
    double median = us[us.size() / 2];
    double min_us = us.front();
    double throughput = (double)count / (avg * 1e-6) / 1e6;

    std::cout << std::fixed << std::setprecision(3);
    std::cout << "=== Encoder Softmax QEMU benchmark ===\n";
    std::cout << "shape        : [" << batch << ", " << heads << ", "
              << qlen << ", " << klen << "]\n";
    std::cout << "elements     : " << count << "\n";
    std::cout << "warmup       : " << warmup << "\n";
    std::cout << "repeat       : " << repeat << "\n";
    std::cout << "min          : " << min_us << " us\n";
    std::cout << "median       : " << median << " us\n";
    std::cout << "average      : " << avg << " us\n";
    std::cout << "throughput   : " << throughput << " M elements/s\n";
    std::cout << "row checksum : " << checksum << " (expected ~" << rows << ")\n";
    std::cout << "max |sum-1|  : " << max_row_sum_error << "\n";
    std::cout << "sanity check : " << (valid ? "PASS" : "FAIL") << "\n";
    return valid ? 0 : 3;
}

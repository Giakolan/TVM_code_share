#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <random>
#include <vector>

extern "C" int whisper_gelu_f32(const float* x, float* y, int64_t count);

static double checksum(const std::vector<float>& v) {
    double s = 0.0;
    for (float x : v) s += x;
    return s;
}

int main(int argc, char** argv) {
    int64_t count = (argc > 1) ? std::atoll(argv[1]) : 1500LL * 1536LL;
    int warmup = (argc > 2) ? std::atoi(argv[2]) : 2;
    int repeat = (argc > 3) ? std::atoi(argv[3]) : 10;

    if (count <= 0 || warmup < 0 || repeat <= 0) {
        std::cerr << "Usage: " << argv[0] << " [count] [warmup] [repeat]\n";
        return 1;
    }

    std::vector<float> x((size_t)count), y((size_t)count);
    std::mt19937 rng(12345);
    std::uniform_real_distribution<float> dist(-4.0f, 4.0f);
    for (auto& v : x) v = dist(rng);

    for (int i = 0; i < warmup; ++i) {
        int rc = whisper_gelu_f32(x.data(), y.data(), count);
        if (rc != 0) {
            std::cerr << "warmup failed, rc=" << rc << "\n";
            return 2;
        }
    }

    std::vector<double> us;
    us.reserve((size_t)repeat);
    for (int i = 0; i < repeat; ++i) {
        auto t0 = std::chrono::steady_clock::now();
        int rc = whisper_gelu_f32(x.data(), y.data(), count);
        auto t1 = std::chrono::steady_clock::now();
        if (rc != 0) {
            std::cerr << "whisper_gelu_f32 failed, rc=" << rc << "\n";
            return 2;
        }
        us.push_back(std::chrono::duration<double, std::micro>(t1 - t0).count());
    }

    bool finite = true;
    for (float v : y) {
        if (!std::isfinite(v)) {
            finite = false;
            break;
        }
    }

    std::sort(us.begin(), us.end());
    double total = 0.0;
    for (double t : us) total += t;
    double avg = total / repeat;
    double median = us[us.size() / 2];
    double min_us = us.front();
    double throughput = (double)count / (avg * 1e-6) / 1e6;

    std::cout << std::fixed << std::setprecision(3);
    std::cout << "=== GELU QEMU benchmark ===\n";
    std::cout << "count        : " << count << "\n";
    std::cout << "warmup       : " << warmup << "\n";
    std::cout << "repeat       : " << repeat << "\n";
    std::cout << "min          : " << min_us << " us\n";
    std::cout << "median       : " << median << " us\n";
    std::cout << "average      : " << avg << " us\n";
    std::cout << "throughput   : " << throughput << " M elements/s\n";
    std::cout << "checksum     : " << checksum(y) << "\n";
    std::cout << "finite check : " << (finite ? "PASS" : "FAIL") << "\n";
    return finite ? 0 : 3;
}
